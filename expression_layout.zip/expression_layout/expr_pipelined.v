// Top Module: 2-Stage Pipelined (A . B) + C Logic
module expr_pipelined (
    input  wire clk,
    input  wire rst,
    input  wire a,
    input  wire b,
    input  wire c,
    output reg  y
);

    // Pipeline registers for Stage 1
    reg stage1_and;
    reg stage1_c;

    // Stage 1: AND operation and register delay for input C
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            stage1_and <= 1'b0;
            stage1_c   <= 1'b0;
        end else begin
            stage1_and <= a & b;
            stage1_c   <= c;
        end
    end

    // Stage 2: OR operation
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            y <= 1'b0;
        end else begin
            y <= stage1_and | stage1_c;
        end
    end

endmodule
