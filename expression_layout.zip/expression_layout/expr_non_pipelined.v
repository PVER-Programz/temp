// Top Module: Non-Pipelined (A . B) + C Logic
module expr_non_pipelined (
    input  wire clk,
    input  wire rst,
    input  wire a,
    input  wire b,
    input  wire c,
    output reg  y
);

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            y <= 1'b0;
        end else begin
            y <= (a & b) | c;
        end
    end

endmodule
