
//input ports
add mapped point clk clk -type PI PI
add mapped point rst rst -type PI PI
add mapped point a a -type PI PI
add mapped point b b -type PI PI
add mapped point c c -type PI PI

//output ports
add mapped point y y -type PO PO

//inout ports




//Sequential Pins
add mapped point y/q y_reg/Q -type DFF DFF
add mapped point stage1_and/q stage1_and_reg/Q -type DFF DFF
add mapped point stage1_c/q stage1_c_reg/Q -type DFF DFF



//Black Boxes



//Empty Modules as Blackboxes
