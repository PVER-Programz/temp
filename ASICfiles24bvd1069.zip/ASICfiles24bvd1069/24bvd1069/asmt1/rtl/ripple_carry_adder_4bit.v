module ripple_carry_adder_4bit (
    input  wire [3:0] a, b,
    input  wire cin,
    output wire [3:0] sum,
    output wire cout
);
    wire c1, c2, c3;

    full_adder_1bit fa0 (a[0], b[0], cin, sum[0], c1);
    full_adder_1bit fa1 (a[1], b[1], c1,  sum[1], c2);
    full_adder_1bit fa2 (a[2], b[2], c2,  sum[2], c3);
    full_adder_1bit fa3 (a[3], b[3], c3,  sum[3], cout);
endmodule
