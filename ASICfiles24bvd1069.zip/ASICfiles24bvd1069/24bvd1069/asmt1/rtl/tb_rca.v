module tb_rca;
    reg [3:0] a, b;
    reg cin;
    wire [3:0] sum;
    wire cout;

    ripple_carry_adder_4bit dut (a, b, cin, sum, cout);

    initial begin
        $monitor("Time=%0t | A=%d B=%d Cin=%b | Sum=%d Cout=%b", $time, a, b, cin, sum, cout);
        a = 4'd0; b = 4'd0; cin = 0;
        #10 a = 4'd5; b = 4'd3; 
        #10 a = 4'd15; b = 4'd1; // Trigger carry
        #10 $finish;
    end
endmodule
