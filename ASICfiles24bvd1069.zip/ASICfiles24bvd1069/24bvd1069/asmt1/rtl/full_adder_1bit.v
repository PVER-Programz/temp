module full_adder_1bit (
    input  wire a, b, cin,
    output wire sum, cout
);
    wire x1, a1, a2;

    // Sum logic: (A ^ B) ^ Cin
    xor (x1, a, b);
    xor (sum, x1, cin);

    // Carry logic: (A & B) | (Cin & (A ^ B))
    and (a1, a, b);
    and (a2, cin, x1);
    or  (cout, a1, a2);
endmodule
