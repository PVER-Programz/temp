1784538223 /home/vlsi25/24bvd1067/asmt1/rtl/tb_rca.v
1784538131 /home/vlsi25/24bvd1067/asmt1/rtl/ripple_carry_adder_4bit.v
1784539178 /home/vlsi25/24bvd1067/asmt1/rtl/full_adder_1bit.v
1784538131 /home/vlsi25/24bvd1067/asmt1/rtl/adder4b.v
