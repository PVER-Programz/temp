1784538493 /home/vlsi25/24bvd1067/asmt1/rtl/cds.lib
1784538514 /home/vlsi25/24bvd1067/asmt1/rtl/hdl.var
1784539178 /home/vlsi25/24bvd1067/asmt1/rtl/full_adder_1bit.v
1784538131 /home/vlsi25/24bvd1067/asmt1/rtl/ripple_carry_adder_4bit.v
1784538223 /home/vlsi25/24bvd1067/asmt1/rtl/tb_rca.v
