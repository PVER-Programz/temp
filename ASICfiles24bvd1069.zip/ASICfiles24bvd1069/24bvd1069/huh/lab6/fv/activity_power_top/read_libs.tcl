add_search_path /home/vlsi14/24BVD1100/lab6/lib -library -both
read_library -liberty -both \
    /home/vlsi14/24BVD1100/lab6/lib/teaching_base.lib \
    /home/vlsi14/24BVD1100/lab6/lib/teaching_base.lib

