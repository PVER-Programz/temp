import os
import re
import matplotlib.pyplot as plt
import numpy as np

# 1. Setup path and files
target_dir = "/home/vlsi14/24BVD1100/lab6/reports"
power_files = [
    "clk_high_power.rpt", 
    "clk_low_power.rpt", 
    "data_high_power.rpt", 
    "data_low_power.rpt"
]

# Dictionaries to hold our extracted data
rise_power = []
fall_power = []
valid_files = []

# 2. Regular Expressions for extraction
# NOTE: You may need to tweak these regex patterns depending on your specific EDA tool 
# (Synopsys DC, Cadence Genus, PrimeTime, etc.). 
# These look for the words "Rise"/"Rising" and "Fall"/"Falling" followed by numbers.
rise_pattern = re.compile(r'Ris[ei].*?([0-9]*\.?[0-9]+[eE]?[-\+]?[0-9]*)', re.IGNORECASE)
fall_pattern = re.compile(r'Fall.*?([0-9]*\.?[0-9]+[eE]?[-\+]?[0-9]*)', re.IGNORECASE)

# 3. Parse the files
for filename in power_files:
    filepath = os.path.join(target_dir, filename)
    
    r_val, f_val = 0.0, 0.0 # Default to 0 if not found
    
    if os.path.exists(filepath):
        with open(filepath, 'r') as file:
            content = file.read()
            
            # Find all matches, usually we want the total/summary at the bottom
            r_matches = rise_pattern.findall(content)
            f_matches = fall_pattern.findall(content)
            
            if r_matches:
                r_val = float(r_matches[-1]) # Grabs the last match in the file
            if f_matches:
                f_val = float(f_matches[-1])
                
        valid_files.append(filename.replace('_power.rpt', '')) # Clean names for the graph
        rise_power.append(r_val)
        fall_power.append(f_val)
    else:
        print(f"Warning: {filename} not found.")

# 4. Generate the Visual Plot
x = np.arange(len(valid_files))
width = 0.35  # Width of the bars

fig, ax = plt.subplots(figsize=(10, 6))
rects1 = ax.bar(x - width/2, rise_power, width, label='Rising Edge Power', color='skyblue', edgecolor='black')
rects2 = ax.bar(x + width/2, fall_power, width, label='Falling Edge Power', color='salmon', edgecolor='black')

# Add labels, title, and custom x-axis tick labels
ax.set_ylabel('Power Dissipation (Units)')
ax.set_title('Rising vs Falling Edge Power Comparison')
ax.set_xticks(x)
ax.set_xticklabels(valid_files)
ax.legend()

# Add values on top of the bars
def autolabel(rects):
    for rect in rects:
        height = rect.get_height()
        ax.annotate(f'{height:.2e}',
                    xy=(rect.get_x() + rect.get_width() / 2, height),
                    xytext=(0, 3),  # 3 points vertical offset
                    textcoords="offset points",
                    ha='center', va='bottom', fontsize=9)

autolabel(rects1)
autolabel(rects2)

fig.tight_layout()

# Save the output to a single image file
output_chart = os.path.join(target_dir, 'power_comparison_chart.png')
plt.savefig(output_chart, dpi=300)
print(f"Success! Visual comparison saved to: {output_chart}")
