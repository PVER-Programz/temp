#!/usr/bin/tclsh

set report_dir "/home/vlsi14/24BVD1100/lab6/reports"

# Procedure to extract Total Power from a given file
proc get_total_power {filepath} {
    if {![file exists $filepath]} {
        puts "Warning: $filepath not found."
        return 0.0
    }
    set fp [open $filepath r]
    set total 0.0
    while {[gets $fp line] >= 0} {
        # Searches for the Subtotal row and captures the 4th value (Total Power)
        if {[regexp {\s*Subtotal\s+[^\s]+\s+[^\s]+\s+[^\s]+\s+([^\s]+)} $line match t]} {
            set total $t
        }
    }
    close $fp
    return $total
}

# Procedure to calculate percentage change
proc calc_pct_change {base new} {
    if {$base == 0.0} { return 0.0 }
    return [expr {(($new - $base) / $base) * 100.0}]
}

# 1. Fetch Total Power from all 4 files
set clk_high  [get_total_power "$report_dir/clk_high_power.rpt"]
set clk_low   [get_total_power "$report_dir/clk_low_power.rpt"]
set data_high [get_total_power "$report_dir/data_high_power.rpt"]
set data_low  [get_total_power "$report_dir/data_low_power.rpt"]

# 2. Calculate the 4 requested transition cases
# Clk 1 to 0 (Base = High, New = Low)
set clk_1_to_0  [calc_pct_change $clk_high $clk_low]
# Clk 0 to 1 (Base = Low, New = High)
set clk_0_to_1  [calc_pct_change $clk_low $clk_high]
# Data 1 to 0 (Base = High, New = Low)
set data_1_to_0 [calc_pct_change $data_high $data_low]
# Data 0 to 1 (Base = Low, New = High)
set data_0_to_1 [calc_pct_change $data_low $data_high]

# 3. Print the visually formatted report table
puts "-----------------------------------------------------------------------------------------"
puts [format "| %-10s | %-15s | %-15s | %-15s | %-15s |" "Signal" "Transition" "Base Power (W)" "New Power (W)" "% Change"]
puts "-----------------------------------------------------------------------------------------"
puts [format "| %-10s | %-15s | %-15.4e | %-15.4e | %+12.2f %% |" "Clock" "1 to 0" $clk_high $clk_low $clk_1_to_0]
puts [format "| %-10s | %-15s | %-15.4e | %-15.4e | %+12.2f %% |" "Clock" "0 to 1" $clk_low $clk_high $clk_0_to_1]
puts [format "| %-10s | %-15s | %-15.4e | %-15.4e | %+12.2f %% |" "Data" "1 to 0" $data_high $data_low $data_1_to_0]
puts [format "| %-10s | %-15s | %-15.4e | %-15.4e | %+12.2f %% |" "Data" "0 to 1" $data_low $data_high $data_0_to_1]
puts "-----------------------------------------------------------------------------------------"
