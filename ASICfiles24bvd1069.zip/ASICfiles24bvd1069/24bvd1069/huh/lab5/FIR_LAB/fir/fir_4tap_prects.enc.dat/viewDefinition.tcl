if {![namespace exists ::IMEX]} { namespace eval ::IMEX {} }
set ::IMEX::dataVar [file dirname [file normalize [info script]]]
set ::IMEX::libVar ${::IMEX::dataVar}/libs

create_library_set -name MAXTIMING\
   -timing\
    [list ${::IMEX::libVar}/mmmc/slow.lib]
create_library_set -name MINTIMING\
   -timing\
    [list ${::IMEX::libVar}/mmmc/fast.lib]
create_rc_corner -name default_rc_corner\
   -preRoute_res 1\
   -postRoute_res 1\
   -preRoute_cap 1\
   -postRoute_cap 1\
   -postRoute_xcap 1\
   -preRoute_clkres 0\
   -preRoute_clkcap 0
create_delay_corner -name BEST\
   -library_set MINTIMING
update_delay_corner -name BEST -power_domain BEST\
   -library_set MINTIMING
create_delay_corner -name WORST\
   -library_set MAXTIMING
update_delay_corner -name WORST -power_domain WORST\
   -library_set MAXTIMING
update_delay_corner -name WORST -power_domain BEST\
   -library_set MINTIMING
create_constraint_mode -name FIR_CONSTRAINT\
   -sdc_files\
    [list /dev/null]
create_analysis_view -name WORSTCASE -constraint_mode FIR_CONSTRAINT -delay_corner WORST
create_analysis_view -name BESTCASE -constraint_mode FIR_CONSTRAINT -delay_corner BEST
set_analysis_view -setup [list WORSTCASE] -hold [list BESTCASE]
