if {![namespace exists ::IMEX]} { namespace eval ::IMEX {} }
set ::IMEX::dataVar [file dirname [file normalize [info script]]]
set ::IMEX::libVar ${::IMEX::dataVar}/libs

create_library_set -name mintime\
   -timing\
    [list ${::IMEX::libVar}/mmmc/slow.lib\
    ${::IMEX::libVar}/mmmc/fast.lib]
create_library_set -name maxtime\
   -timing\
    [list ${::IMEX::libVar}/mmmc/slow.lib]
create_rc_corner -name default_rc_corner\
   -preRoute_res 1\
   -postRoute_res 1\
   -preRoute_cap 1\
   -postRoute_cap 1\
   -postRoute_xcap 1\
   -preRoute_clkres 0\
   -preRoute_clkcap 0
create_delay_corner -name worstcase\
   -library_set maxtime
create_delay_corner -name bestcase\
   -library_set mintime
create_constraint_mode -name const\
   -sdc_files\
    [list /dev/null]
create_analysis_view -name worst -constraint_mode const -delay_corner worstcase
create_analysis_view -name best -constraint_mode const -delay_corner bestcase
set_analysis_view -setup [list worst] -hold [list best]
