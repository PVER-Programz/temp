#######################################################
#                                                     
#  Innovus Command Logging File                     
#  Created on Wed Sep  2 18:27:28 2026                
#                                                     
#######################################################

#@(#)CDS: Innovus v21.15-s110_1 (64bit) 09/23/2022 13:08 (Linux 3.10.0-693.el7.x86_64)
#@(#)CDS: NanoRoute 21.15-s110_1 NR220912-2004/21_15-UB (database version 18.20.592) {superthreading v2.17}
#@(#)CDS: AAE 21.15-s039 (64bit) 09/23/2022 (Linux 3.10.0-693.el7.x86_64)
#@(#)CDS: CTE 21.15-s038_1 () Sep 20 2022 11:42:13 ( )
#@(#)CDS: SYNTECH 21.15-s012_1 () Sep  5 2022 10:25:51 ( )
#@(#)CDS: CPE v21.15-s076
#@(#)CDS: IQuantus/TQuantus 21.1.1-s867 (64bit) Sun Jun 26 22:12:54 PDT 2022 (Linux 3.10.0-693.el7.x86_64)

set_global _enable_mmmc_by_default_flow      $CTE::mmmc_default
suppressMessage ENCEXT-2799
getVersion
getVersion
getVersion
win
save_global Default.globals
set init_gnd_net gnd
set init_lef_file ../../../../../install/FOUNDRY/digital/90nm/dig/lef/gsclib090_translated.lef
set init_verilog 90nm/slow/output/netlist/fir_4tap_pipelined_opt.v
set init_mmmc_file Default.view
set init_pwr_net vdd
init_design
getIoFlowFlag
setIoFlowFlag 0
floorPlan -site gsclib090site -r 0.963486076559 0.7 8 8 8 8
uiSetTool select
getIoFlowFlag
fit
setIoFlowFlag 0
floorPlan -site gsclib090site -r 0.88 0.698788 8.12 8.12 8.12 8.12
uiSetTool select
getIoFlowFlag
fit
set sprCreateIeRingOffset 1.0
set sprCreateIeRingThreshold 1.0
set sprCreateIeRingJogDistance 1.0
set sprCreateIeRingLayers {}
set sprCreateIeRingOffset 1.0
set sprCreateIeRingThreshold 1.0
set sprCreateIeRingJogDistance 1.0
set sprCreateIeRingLayers {}
set sprCreateIeStripeWidth 10.0
set sprCreateIeStripeThreshold 1.0
set sprCreateIeStripeWidth 10.0
set sprCreateIeStripeThreshold 1.0
set sprCreateIeRingOffset 1.0
set sprCreateIeRingThreshold 1.0
set sprCreateIeRingJogDistance 1.0
set sprCreateIeRingLayers {}
set sprCreateIeStripeWidth 10.0
set sprCreateIeStripeThreshold 1.0
setAddRingMode -ring_target default -extend_over_row 0 -ignore_rows 0 -avoid_short 0 -skip_crossing_trunks none -stacked_via_top_layer Metal9 -stacked_via_bottom_layer Metal1 -via_using_exact_crossover_size 1 -orthogonal_only true -skip_via_on_pin {  standardcell } -skip_via_on_wire_shape {  noshape }
addRing -nets {gnd vdd} -type core_rings -follow core -layer {top Metal9 bottom Metal9 left Metal8 right Metal8} -width {top 1.8 bottom 1.8 left 1.8 right 1.8} -spacing {top 0.5 bottom 0.5 left 0.5 right 0.5} -offset {top 1.8 bottom 1.8 left 1.8 right 1.8} -center 0 -threshold 0 -jog_distance 0 -snap_wire_center_to_grid None
setAddRingMode -ring_target default -extend_over_row 0 -ignore_rows 0 -avoid_short 0 -skip_crossing_trunks none -stacked_via_top_layer Metal9 -stacked_via_bottom_layer Metal1 -via_using_exact_crossover_size 1 -orthogonal_only true -skip_via_on_pin {  standardcell } -skip_via_on_wire_shape {  noshape }
addRing -nets {gnd vdd} -type core_rings -follow core -layer {top Metal9 bottom Metal9 left Metal8 right Metal8} -width {top 1.8 bottom 1.8 left 1.8 right 1.8} -spacing {top 0.5 bottom 0.5 left 0.5 right 0.5} -offset {top 1.8 bottom 1.8 left 1.8 right 1.8} -center 0 -threshold 0 -jog_distance 0 -snap_wire_center_to_grid None
set sprCreateIeRingOffset 1.0
set sprCreateIeRingThreshold 1.0
set sprCreateIeRingJogDistance 1.0
set sprCreateIeRingLayers {}
set sprCreateIeRingOffset 1.0
set sprCreateIeRingThreshold 1.0
set sprCreateIeRingJogDistance 1.0
set sprCreateIeRingLayers {}
set sprCreateIeStripeWidth 10.0
set sprCreateIeStripeThreshold 1.0
set sprCreateIeStripeWidth 10.0
set sprCreateIeStripeThreshold 1.0
set sprCreateIeRingOffset 1.0
set sprCreateIeRingThreshold 1.0
set sprCreateIeRingJogDistance 1.0
set sprCreateIeRingLayers {}
set sprCreateIeStripeWidth 10.0
set sprCreateIeStripeThreshold 1.0
setAddStripeMode -ignore_block_check false -break_at none -route_over_rows_only false -rows_without_stripes_only false -extend_to_closest_target none -stop_at_last_wire_for_area false -partial_set_thru_domain false -ignore_nondefault_domains false -trim_antenna_back_to_shape none -spacing_type edge_to_edge -spacing_from_block 0 -stripe_min_length stripe_width -stacked_via_top_layer Metal9 -stacked_via_bottom_layer Metal1 -via_using_exact_crossover_size false -split_vias false -orthogonal_only true -allow_jog { padcore_ring  block_ring } -skip_via_on_pin {  standardcell } -skip_via_on_wire_shape {  noshape   }
addStripe -nets {} -layer Metal8 -direction vertical -width 1.8 -spacing 0.5 -number_of_sets 3 -start_from left -switch_layer_over_obs false -max_same_layer_jog_length 2 -padcore_ring_top_layer_limit Metal9 -padcore_ring_bottom_layer_limit Metal1 -block_ring_top_layer_limit Metal9 -block_ring_bottom_layer_limit Metal1 -use_wire_group 0 -snap_wire_center_to_grid None
setAddStripeMode -ignore_block_check false -break_at none -route_over_rows_only false -rows_without_stripes_only false -extend_to_closest_target none -stop_at_last_wire_for_area false -partial_set_thru_domain false -ignore_nondefault_domains false -trim_antenna_back_to_shape none -spacing_type edge_to_edge -spacing_from_block 0 -stripe_min_length stripe_width -stacked_via_top_layer Metal9 -stacked_via_bottom_layer Metal1 -via_using_exact_crossover_size false -split_vias false -orthogonal_only true -allow_jog { padcore_ring  block_ring } -skip_via_on_pin {  standardcell } -skip_via_on_wire_shape {  noshape   }
addStripe -nets {} -layer Metal8 -direction vertical -width 1.8 -spacing 0.5 -number_of_sets 3 -start_from left -switch_layer_over_obs false -max_same_layer_jog_length 2 -padcore_ring_top_layer_limit Metal9 -padcore_ring_bottom_layer_limit Metal1 -block_ring_top_layer_limit Metal9 -block_ring_bottom_layer_limit Metal1 -use_wire_group 0 -snap_wire_center_to_grid None
setAddStripeMode -ignore_block_check false -break_at none -route_over_rows_only false -rows_without_stripes_only false -extend_to_closest_target none -stop_at_last_wire_for_area false -partial_set_thru_domain false -ignore_nondefault_domains false -trim_antenna_back_to_shape none -spacing_type edge_to_edge -spacing_from_block 0 -stripe_min_length stripe_width -stacked_via_top_layer Metal9 -stacked_via_bottom_layer Metal1 -via_using_exact_crossover_size false -split_vias false -orthogonal_only true -allow_jog { padcore_ring  block_ring } -skip_via_on_pin {  standardcell } -skip_via_on_wire_shape {  noshape   }
addStripe -nets {gnd vdd} -layer Metal8 -direction vertical -width 1.8 -spacing 0.5 -number_of_sets 3 -start_from left -switch_layer_over_obs false -max_same_layer_jog_length 2 -padcore_ring_top_layer_limit Metal9 -padcore_ring_bottom_layer_limit Metal1 -block_ring_top_layer_limit Metal9 -block_ring_bottom_layer_limit Metal1 -use_wire_group 0 -snap_wire_center_to_grid None
setAddStripeMode -ignore_block_check false -break_at none -route_over_rows_only false -rows_without_stripes_only false -extend_to_closest_target none -stop_at_last_wire_for_area false -partial_set_thru_domain false -ignore_nondefault_domains false -trim_antenna_back_to_shape none -spacing_type edge_to_edge -spacing_from_block 0 -stripe_min_length stripe_width -stacked_via_top_layer Metal9 -stacked_via_bottom_layer Metal1 -via_using_exact_crossover_size false -split_vias false -orthogonal_only true -allow_jog { padcore_ring  block_ring } -skip_via_on_pin {  standardcell } -skip_via_on_wire_shape {  noshape   }
addStripe -nets {gnd vdd} -layer Metal9 -direction horizontal -width 1.8 -spacing 0.5 -number_of_sets 3 -start_from bottom -switch_layer_over_obs false -max_same_layer_jog_length 2 -padcore_ring_top_layer_limit Metal9 -padcore_ring_bottom_layer_limit Metal1 -block_ring_top_layer_limit Metal9 -block_ring_bottom_layer_limit Metal1 -use_wire_group 0 -snap_wire_center_to_grid None
setSrouteMode -viaConnectToShape { noshape }
sroute -connect { blockPin padPin padRing corePin floatingStripe } -layerChangeRange { Metal1(1) Metal9(9) } -blockPinTarget { nearestTarget } -padPinPortConnect { allPort oneGeom } -padPinTarget { nearestTarget } -corePinTarget { firstAfterRowEnd } -floatingStripeTarget { blockring padring ring stripe ringpin blockpin followpin } -allowJogging 1 -crossoverViaLayerRange { Metal1(1) Metal9(9) } -allowLayerChange 1 -blockPin useLef -targetViaLayerRange { Metal1(1) Metal9(9) }
setSrouteMode -viaConnectToShape { noshape }
sroute -connect { blockPin padPin padRing corePin floatingStripe } -layerChangeRange { Metal1(1) Metal9(9) } -blockPinTarget { nearestTarget } -padPinPortConnect { allPort oneGeom } -padPinTarget { nearestTarget } -corePinTarget { firstAfterRowEnd } -floatingStripeTarget { blockring padring ring stripe ringpin blockpin followpin } -allowJogging 1 -crossoverViaLayerRange { Metal1(1) Metal9(9) } -allowLayerChange 1 -blockPin useLef -targetViaLayerRange { Metal1(1) Metal9(9) }
clearGlobalNets
globalNetConnect vdd -type pgpin -pin vdd -instanceBasename * -hierarchicalInstance {}
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
clearGlobalNets
globalNetConnect vdd -type pgpin -pin vdd -instanceBasename * -hierarchicalInstance {}
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
setRouteMode -earlyGlobalHonorMsvRouteConstraint false -earlyGlobalRoutePartitionPinGuide true
setEndCapMode -reset
setEndCapMode -boundary_tap false
setNanoRouteMode -quiet -droutePostRouteSpreadWire 1
setNanoRouteMode -quiet -droutePostRouteWidenWireRule LEFDefaultRouteSpec_gpdk090
setNanoRouteMode -quiet -timingEngine {}
setUsefulSkewMode -noBoundary false -maxAllowedDelay 1
setPlaceMode -reset
setPlaceMode -congEffort auto -timingDriven 1 -clkGateAware 1 -powerDriven 0 -ignoreScan 1 -reorderScan 1 -ignoreSpare 0 -placeIOPins 1 -moduleAwareSpare 0 -preserveRouting 1 -rmAffectedRouting 0 -checkRoute 0 -swapEEQ 0
setRouteMode -earlyGlobalHonorMsvRouteConstraint false -earlyGlobalRoutePartitionPinGuide true
setEndCapMode -reset
setEndCapMode -boundary_tap false
setUsefulSkewMode -noBoundary false -maxAllowedDelay 1
setPlaceMode -fp false
place_design
setPlaceMode -fp false
place_design
saveDesign fir_4tap_pipelined_prects.enc
saveDesign fir_4tap_pipelined_prects.enc
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -preCTS -pathReports -drvReports -slackReports -numPaths 50 -prefix fir_4tap_pipelined_preCTS -outDir timingReports
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -preCTS -hold -pathReports -slackReports -numPaths 50 -prefix fir_4tap_pipelined_preCTS -outDir timingReports
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -preCTS -hold -pathReports -slackReports -numPaths 50 -prefix fir_4tap_pipelined_preCTS -outDir timingReports
report_area
report_power
setOptMode -fixCap true -fixTran true -fixFanoutLoad false
optDesign -preCTS
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -preCTS -pathReports -drvReports -slackReports -numPaths 50 -prefix fir_4tap_pipelined_preCTS -outDir timingReports
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -preCTS -hold -pathReports -slackReports -numPaths 50 -prefix fir_4tap_pipelined_preCTS -outDir timingReports
report_area
report_power
getCTSMode -engine -quiet
create_ccopt_clock_tree_spec
ctd_win -side none -id ctd_window
selectObject Net clk
zoomSelected
ctd_win -side none -id ctd_window
fit
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -postCTS -pathReports -drvReports -slackReports -numPaths 50 -prefix fir_4tap_pipelined_postCTS -outDir timingReports
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -postCTS -hold -pathReports -slackReports -numPaths 50 -prefix fir_4tap_pipelined_postCTS -outDir timingReports
report_power
report_area
setOptMode -fixCap true -fixTran true -fixFanoutLoad false
optDesign -postCTS
optDesign -postCTS -hold
setOptMode -fixCap true -fixTran true -fixFanoutLoad false
optDesign -postCTS
optDesign -postCTS -hold
setNanoRouteMode -quiet -routeWithTimingDriven 1
setNanoRouteMode -quiet -routeWithEco 1
setNanoRouteMode -quiet -routeWithSiDriven 1
setNanoRouteMode -quiet -routeTopRoutingLayer 9
setNanoRouteMode -quiet -routeBottomRoutingLayer 1
setNanoRouteMode -quiet -drouteEndIteration 1
setNanoRouteMode -quiet -routeWithTimingDriven true
setNanoRouteMode -quiet -routeWithSiDriven true
routeDesign -globalDetail
setNanoRouteMode -quiet -routeWithTimingDriven 1
setNanoRouteMode -quiet -routeWithEco 1
setNanoRouteMode -quiet -routeWithSiDriven 1
setNanoRouteMode -quiet -routeWithTimingDriven true
setNanoRouteMode -quiet -routeWithSiDriven true
routeDesign -globalDetail
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -postCTS -pathReports -slackReports -numPaths 50 -prefix fir_4tap_pipelined_postCTS -outDir timingReports
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -postCTS -hold -pathReports -slackReports -numPaths 50 -prefix fir_4tap_pipelined_postCTS -outDir timingReports
redirect -quiet {set honorDomain [getAnalysisMode -honorClockDomains]} > /dev/null
timeDesign -postCTS -hold -pathReports -slackReports -numPaths 50 -prefix fir_4tap_pipelined_postCTS -outDir timingReports
setOptMode -fixCap true -fixTran true -fixFanoutLoad false
optDesign -postCTS
optDesign -postCTS -hold
report_power
setAnalysisMode -cppr both -clockGatingCheck true -timeBorrowing true -useOutputPinCap true -sequentialConstProp false -timingSelfLoopsNoSkew false -enableMultipleDriveNet true -clkSrcPath true -warn true -usefulSkew true -analysisType onChipVariation -log true
setOptMode -fixCap true -fixTran true -fixFanoutLoad false
optDesign -postRoute
getCTSMode -engine -quiet
getCTSMode -engine -quiet
setNanoRouteMode -quiet -routeWithTimingDriven true
setNanoRouteMode -quiet -routeWithSiDriven true
routeDesign -globalDetail
setOptMode -fixCap true -fixTran true -fixFanoutLoad false
optDesign -postRoute
optDesign -postRoute -hold
setOptMode -fixCap true -fixTran true -fixFanoutLoad false
optDesign -postRoute
optDesign -postRoute -hold
report_power
report_area
gui_select -rect {-35.86400 45.82900 -34.40600 44.37100}
deselectAll
gui_select -rect {-34.40600 44.37100 -30.42050 43.98200}
getMultiCpuUsage -localCpu
get_verify_drc_mode -disable_rules -quiet
get_verify_drc_mode -quiet -area
get_verify_drc_mode -quiet -layer_range
get_verify_drc_mode -check_ndr_spacing -quiet
get_verify_drc_mode -check_only -quiet
get_verify_drc_mode -check_same_via_cell -quiet
get_verify_drc_mode -exclude_pg_net -quiet
get_verify_drc_mode -ignore_trial_route -quiet
get_verify_drc_mode -max_wrong_way_halo -quiet
get_verify_drc_mode -use_min_spacing_on_block_obs -quiet
get_verify_drc_mode -limit -quiet
set_verify_drc_mode -disable_rules {} -check_ndr_spacing auto -check_only default -check_same_via_cell true -exclude_pg_net false -ignore_trial_route false -ignore_cell_blockage false -use_min_spacing_on_block_obs auto -report fir_4tap_pipelined.drc.rpt -limit 1000
verify_drc
set_verify_drc_mode -area {0 0 0 0}
getCTSMode -engine -quiet
getCTSMode -engine -quiet
gui_select -rect {-11.56200 53.89750 42.29100 14.13950}
deselectAll
zoomBox -30.73150 2.71700 106.67650 69.14900
zoomBox -24.13850 8.04600 92.65900 64.51350
zoomBox -13.77100 16.42650 70.61600 57.22450
zoomBox -6.24750 22.49400 54.72250 51.97100
zoomBox 0.88150 29.11450 38.32600 47.21750
zoomBox 4.05050 32.03550 31.10450 45.11500
zoomBox 7.30250 34.91300 23.91700 42.94550
zoomBox 9.63850 37.13350 18.31150 41.32650
zoomBox 6.90650 35.03650 23.52200 43.06950
zoomBox 1.67300 31.01950 33.50350 46.40850
zoomBox -8.35300 23.32500 52.62550 52.80600
zoomBox -38.33800 5.16000 78.47850 61.63650
zoomBox -95.77700 -29.63800 128.00650 78.55300
zoomBox -70.22300 -17.12350 119.99300 74.83900
zoomBox -48.50200 -6.48600 113.18150 71.68200
zoomBox -14.34550 10.24100 102.47100 66.71750
zoomBox 1.21850 20.70800 85.61900 61.51250
zoomBox 17.00000 31.17200 68.83350 56.23150
zoomBox 26.66950 36.86050 58.50250 52.25050
zoomBox 17.77350 34.47050 61.83350 55.77200
zoomBox 0.45900 21.61450 99.75950 69.62250
zoomBox -21.90200 6.38200 139.79200 84.55500
zoomBox -58.09650 -16.56850 205.19500 110.72350
zoomBox -22.29700 -6.54950 139.39800 71.62400
zoomBox -6.48600 -2.12450 110.33900 54.35600
zoomBox 7.36000 5.72500 79.10550 40.41150
zoomBox 10.65950 7.60150 71.64450 37.08550
zoomBox 15.56400 10.28750 59.62600 31.59000
zoomBox -2.07600 -0.81100 82.33550 39.99900
zoomBox -16.25000 -9.72050 100.58350 46.76400
clearGlobalNets
globalNetConnect vdd -type pgpin -pin vdd -instanceBasename * -hierarchicalInstance {}
clearGlobalNets
globalNetConnect vdd -type pgpin -pin vdd -instanceBasename * -hierarchicalInstance {}
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
zoomBox -28.79650 -17.90300 108.65450 48.54950
zoomBox -43.55750 -27.52950 118.15000 50.65000
zoomBox -60.92300 -38.85500 129.32100 53.12100
fit
get_verify_drc_mode -disable_rules -quiet
get_verify_drc_mode -quiet -area
get_verify_drc_mode -quiet -layer_range
get_verify_drc_mode -check_ndr_spacing -quiet
get_verify_drc_mode -check_only -quiet
get_verify_drc_mode -check_same_via_cell -quiet
get_verify_drc_mode -exclude_pg_net -quiet
get_verify_drc_mode -ignore_trial_route -quiet
get_verify_drc_mode -max_wrong_way_halo -quiet
get_verify_drc_mode -use_min_spacing_on_block_obs -quiet
get_verify_drc_mode -limit -quiet
set_verify_drc_mode -disable_rules {} -check_ndr_spacing auto -check_only default -check_same_via_cell true -exclude_pg_net false -ignore_trial_route false -ignore_cell_blockage false -use_min_spacing_on_block_obs auto -report fir_4tap_pipelined.drc.rpt -limit 1000
verify_drc
set_verify_drc_mode -area {0 0 0 0}
zoomBox -105.24850 -32.48200 204.43650 117.23950
zoomBox -280.35450 -108.36100 417.59750 229.07350
zoomBox -800.19100 -333.62350 1050.40950 561.07450
zoomBox -1846.57800 -787.05800 2324.21050 1229.36650
zoomBox -4952.97850 -2133.16500 6105.73550 3213.32100
zoomBox -11205.91450 -4842.77100 13717.64250 7206.86200
zoomBox -21498.52600 -9302.90350 26247.18100 13780.40900
zoomBox -57059.49850 -24712.65900 69536.73600 36492.01500
zoomBox -151348.28850 -65571.13450 184317.62150 96711.12150
zoomBox -341144.06200 -147815.96950 415362.34200 217927.35500
fit
clearGlobalNets
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
clearGlobalNets
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
clearGlobalNets
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
clearGlobalNets
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
clearGlobalNets
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
clearGlobalNets
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
clearGlobalNets
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
clearGlobalNets
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
clearGlobalNets
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
clearGlobalNets
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
clearGlobalNets
globalNetConnect gnd -type pgpin -pin gnd -instanceBasename * -hierarchicalInstance {}
