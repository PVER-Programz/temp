# Automatically locate the optimized netlist file
set netlist_files [glob -nocomplain *_opt.v]
if {[llength $netlist_files] == 0} {
    puts "Error: No *_opt.v file found in current directory."
    return
}
set netlist_file [lindex $netlist_files 0]

# Determine top-level module name from filename
if {[string match "*shared_mult*" $netlist_file]} {
    set top_module "fir_4tap_shared_mult"
} elseif {[string match "*pipelined*" $netlist_file]} {
    set top_module "fir_4tap_pipelined"
} else {
    set top_module "fir_4tap"
}

# Detect technology node from directory path
set current_path [pwd]
set tech "180nm"
if {[string match "*90nm*" $current_path]} {
    set tech "90nm"
} elseif {[string match "*45nm*" $current_path]} {
    set tech "45nm"
}

# Locate library file based on tech node
set lib_dir "/home/install/FOUNDRY/digital/$tech/dig/lib"
set lib_files [glob -nocomplain "$lib_dir/*.lib"]

if {[llength $lib_files] > 0} {
    # Load first matching library
    read_libs [lindex $lib_files 0]
} else {
    puts "Warning: Could not auto-detect library in $lib_dir. Please read_libs manually."
}

# Load netlist, elaborate, and open GUI
read_hdl -netlist $netlist_file
elaborate $top_module
gui_show
