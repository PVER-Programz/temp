#!/usr/bin/env tclsh
# ====================================================================
# Individual Architecture Report Generator for Cadence Genus
# Generates separate summary files for each FIR architecture
# RUN COMMAND: tclsh parse_individual_reports.tcl
# ====================================================================

set root_dir "."

proc find_files {dir pattern} {
    set files {}
    foreach item [glob -nocomplain -directory $dir *] {
        if {[file isdirectory $item]} {
            set files [concat $files [find_files $item $pattern]]
        } elseif {[string match $pattern [file tail $item]]} {
            lappend files $item
        }
    }
    return $files
}

proc extract_floats {line} {
    set numbers {}
    foreach token [split [string map {\t " " , " "} $line] " "] {
        set clean [string trim $token " ()"]
        if {[regexp {^-?[\d]+\.?[\d]*([eE][+-]?[\d]+)?$} $clean]} {
            lappend numbers $clean
        }
    }
    return $numbers
}

proc to_uW {val} {
    if {$val eq "N/A" || ![string is double -strict $val]} { return $val }
    return [format "%.2f" [expr {$val * 1e6}]]
}

set records {}
set power_reports [find_files $root_dir "*_power.rpt"]

foreach pwr_file $power_reports {
    set rpt_dir [file dirname $pwr_file]
    set path_split [file split $pwr_file]

    # Directory layout: <arch>/<corner>/<freq>/output/reports/
    set freq   [lindex $path_split end-3]
    set corner [lindex $path_split end-4]
    set arch   [lindex $path_split end-5]

    set area "N/A"; set insts "N/A"
    set wns "N/A"; set tns "N/A"
    set leakage "N/A"; set dynamic "N/A"; set total_pwr "N/A"

    # 1. Parse Power
    if {[file exists $pwr_file]} {
        set fp [open $pwr_file "r"]
        while {[gets $fp line] >= 0} {
            set line_lower [string tolower $line]
            if {[string match "*fir_4tap*" $line_lower] || [string match "*total*" $line_lower]} {
                set nums [extract_floats $line]
                if {[llength $nums] >= 3} {
                    set leakage [lindex $nums end-2]
                    set dynamic [lindex $nums end-1]
                    set total_pwr [lindex $nums end]
                }
            }
        }
        close $fp
    }

    # 2. Parse Area & Instances
    set area_files [glob -nocomplain "$rpt_dir/*area*.rpt"]
    if {[llength $area_files] > 0} {
        set fp [open [lindex $area_files 0] "r"]
        while {[gets $fp line] >= 0} {
            if {[regexp {^\s*([a-zA-Z0-9_]+)\s+(\d+)\s+([\d\.]+)\s+([\d\.]+)\s+([\d\.]+)} $line -> inst count c_area n_area t_area]} {
                if {$insts eq "N/A"} { set insts $count }
                if {$area eq "N/A"}  { set area [format "%.2f" $t_area] }
            }
        }
        close $fp
    }
    
    # 3. Parse Timing (WNS Slack)
    set timing_files [glob -nocomplain "$rpt_dir/*timing*.rpt"]
    if {[llength $timing_files] > 0} {
        set fp [open [lindex $timing_files 0] "r"]
        while {[gets $fp line] >= 0} {
            if {[regexp -nocase {Slack[^\d\+\-]*([+\-]?[0-9\.]+)} $line match val]} {
                set wns $val
            }
        }
        close $fp
    }

    lappend records [dict create arch $arch corner $corner freq $freq area $area insts $insts wns $wns tns $tns leakage [to_uW $leakage] dynamic [to_uW $dynamic] total [to_uW $total_pwr]]
}

# Identify all unique architectures
set arch_list {}
foreach r $records {
    set a [dict get $r arch]
    if {$a ni $arch_list && $a ne "Unknown"} {
        lappend arch_list $a
    }
}

# Generate an independent report file for each architecture
foreach target_arch $arch_list {
    set out_file "synthesis_summary_${target_arch}.txt"
    set fp [open $out_file "w"]

    set arch_title [string toupper $target_arch]

    puts $fp "╔══════════════════════════════════════════════════════════════════════════════════════════════════════╗"
    puts $fp [format "║                      SYNTHESIS REPORT: %-52s ║" $arch_title]
    puts $fp "╚══════════════════════════════════════════════════════════════════════════════════════════════════════╝"
    puts $fp ""

    # Executive baseline row (typical @ 1mhz)
    puts $fp "┌──────────────────────────────────────────────────────────────────────────────────────────────────────┐"
    puts $fp "│ BASELINE SUMMARY (Corner: typical | Clock: 1mhz)                                                     │"
    puts $fp "├─────────────────┬──────────────┬────────────┬──────────────────┬──────────────────┬──────────────────┤"
    puts $fp "│ Corner / Clock  │ Area (um²)   │ Instances  │ Leakage (uW)     │ Dynamic (uW)     │ Total Power (uW) │"
    puts $fp "├─────────────────┼──────────────┼────────────┼──────────────────┼──────────────────┼──────────────────┤"

    set baseline_found 0
    foreach r $records {
        if {[dict get $r arch] eq $target_arch && [dict get $r corner] eq "typical" && [dict get $r freq] eq "1mhz"} {
            puts $fp [format "│ %-15s │ %-12s │ %-10s │ %-16s │ %-16s │ %-16s │" \
                "typical/1mhz" [dict get $r area] [dict get $r insts] [dict get $r leakage] [dict get $r dynamic] [dict get $r total]]
            set baseline_found 1
        }
    }
    if {!$baseline_found} {
        puts $fp "│ No baseline record (typical/1mhz) found for this architecture.                                       │"
    }
    puts $fp "└─────────────────┴──────────────┴────────────┴──────────────────┴──────────────────┴──────────────────┘"
    puts $fp ""

    # Full Matrix Breakdown
    puts $fp "┌──────────────────────────────────────────────────────────────────────────────────────────────────────┐"
    puts $fp "│ COMPLETE CORNER & FREQUENCY VARIATION MATRIX                                                         │"
    puts $fp "├──────────┬──────────┬───────────┬───────┬──────────┬────────────────┬────────────────┬───────────────┤"
    puts $fp "│ Corner   │ Freq     │ Area(um²) │ Insts │ WNS(ps)  │ Leakage(uW)    │ Dynamic(uW)    │ Total(uW)     │"
    puts $fp "├──────────┼──────────┼───────────┼───────┼──────────┼────────────────┼────────────────┼───────────────┤"

    foreach r $records {
        if {[dict get $r arch] eq $target_arch} {
            puts $fp [format "│ %-8s │ %-8s │ %-9s │ %-5s │ %-8s │ %-14s │ %-14s │ %-13s │" \
                [dict get $r corner] [dict get $r freq] [dict get $r area] [dict get $r insts] [dict get $r wns] [dict get $r leakage] [dict get $r dynamic] [dict get $r total]]
        }
    }
    puts $fp "└──────────┴──────────┴───────────┴───────┴──────────┴────────────────┴────────────────┴───────────────┘"

    close $fp
    puts "Generated: $out_file"
}

puts "\nAll individual architecture reports successfully created."
