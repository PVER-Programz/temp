# ====================================================================
# Bulletproof Master Synthesis Script for lab5.2 
# RUN COMMAND: genus -f run_lab5_2.tcl
# ====================================================================

puts "\n================================================================="
puts "INITIALIZING SCRIPT..."
puts "Current Directory: [pwd]"
puts "=================================================================\n"

set base_dir [pwd]

# --------------------------------------------------------------------
# DIAGNOSTIC 1: Did you run this with Genus?
# --------------------------------------------------------------------
if {[catch {set_db init_lib_search_path /home/install/FOUNDRY/digital/90nm/dig/lib} err]} {
    puts "\n#########################################################################"
    puts ">>> CRITICAL ERROR: You ran this with 'tclsh'!"
    puts ">>> You MUST run this script by typing: genus -f run_lab5_2.tcl"
    puts "#########################################################################\n"
    exit
}

array set design_mapping {
    "fir"                {"fir_4tap"             "fir_4tap.v"             "fir_4tap.sdc"}
    "fir_area_optimized" {"fir_4tap_shared_mult" "fir_4tap_shared_mult.v" "fir_4tap_shared_mult.sdc"}
    "fir_piplined"       {"fir_4tap_pipelined"   "fir_4tap_pipelined.v"   "fir_4tap_pipelined.sdc"}
}
set design_folders {"fir" "fir_area_optimized" "fir_piplined"}

array set lib_mapping {
    "slow"    "slow.lib"
    "typical" "typical.lib"
    "fast"    "fast.lib"
}
set lib_names {"slow" "typical" "fast"}

array set period_mapping {
    "1khz" 1000000.0
    "1mhz" 1000.0
    "1ghz" 1.0
}
set freq_names {"1khz" "1mhz" "1ghz"}

# ====================================================================
# Execution Loop
# ====================================================================

foreach des_dir $design_folders {
    
    set TOP_MODULE [lindex $design_mapping($des_dir) 0]
    set v_file     [lindex $design_mapping($des_dir) 1]
    set sdc_file   [lindex $design_mapping($des_dir) 2]
    
    # --------------------------------------------------------------------
    # DIAGNOSTIC 2: Are we in the right folder?
    # --------------------------------------------------------------------
    if {![file exists $des_dir]} {
        puts ">>> WARNING: Cannot find the folder '$des_dir'."
        puts ">>> Are you sure your terminal is opened in the lab5.2 folder?"
        continue
    }
    
    cd $des_dir
    set_db init_hdl_search_path [pwd]
    
    foreach lib_name $lib_names {
        
        set current_lib $lib_mapping($lib_name)
        set_db library $current_lib
        
        foreach freq_name $freq_names {
            
            set period_ns $period_mapping($freq_name)
            
            puts "\n---------------------------------------------------------------------"
            puts "Synthesizing: Design = $TOP_MODULE | Lib = $lib_name | Freq = $freq_name"
            puts "---------------------------------------------------------------------"
            
            # Create the nested target directories
            set out_dir "${lib_name}/${freq_name}/output"
            file mkdir $out_dir/netlist
            file mkdir $out_dir/constraints
            file mkdir $out_dir/reports
            
            # --------------------------------------------------------------------
            # DIAGNOSTIC 3: Catching Synthesis Errors
            # Wrap the synthesis in a catch block so a crash doesn't kill the script!
            # --------------------------------------------------------------------
            if {[catch {
                read_hdl $v_file
                elaborate $TOP_MODULE
                read_sdc $sdc_file
                
                # Override the clock for the specific frequency target
                catch { create_clock -name CLK -period $period_ns [get_ports clk] }
                
                set_db syn_generic_effort medium
                set_db syn_map_effort medium
                set_db syn_opt_effort medium
                
                syn_generic
                write_hdl > ${out_dir}/netlist/${TOP_MODULE}_generic.v
                
                syn_map
                write_hdl > ${out_dir}/netlist/${TOP_MODULE}_mapped.v
                
                syn_opt
                write_hdl > ${out_dir}/netlist/${TOP_MODULE}_opt.v
                write_sdc > ${out_dir}/constraints/${TOP_MODULE}_synth.sdc
                
                report_timing > ${out_dir}/reports/${TOP_MODULE}_timing.rpt
                report_power  > ${out_dir}/reports/${TOP_MODULE}_power.rpt
                report_area   > ${out_dir}/reports/${TOP_MODULE}_area.rpt
                report_gates  > ${out_dir}/reports/${TOP_MODULE}_gates.rpt
                report_qor    > ${out_dir}/reports/${TOP_MODULE}_qor.rpt
                
                delete_obj /designs/*
                
            } err]} {
                puts ">>> SYNTHESIS FAILED for $freq_name! Error: $err"
                puts ">>> Skipping to the next combination..."
                catch { delete_obj /designs/* }
            }
        }
    }
    
    # Jump back out to lab5.2 before moving to the next design
    cd $base_dir
}

puts "\n================================================="
puts "ALL SYNTHESIS RUNS ATTEMPTED AND COMPLETED!"
puts "=================================================\n"
gui_show
