# ====================================================================
# Master Synthesis Script (Technology Variation - Caching Fix)
# RUN COMMAND: genus -f run_lab5_2_tech.tcl
# ====================================================================

puts "\n================================================================="
puts "INITIALIZING SCRIPT: TECHNOLOGY SWAP (ABSOLUTE PATH FIX)"
puts "=================================================================\n"

set base_dir [pwd]

array set design_mapping {
    "fir"                {"fir_4tap"             "fir_4tap.v"             "fir_4tap.sdc"}
    "fir_area_optimized" {"fir_4tap_shared_mult" "fir_4tap_shared_mult.v" "fir_4tap_shared_mult.sdc"}
    "fir_piplined"       {"fir_4tap_pipelined"   "fir_4tap_pipelined.v"   "fir_4tap_pipelined.sdc"}
}
set design_folders {"fir" "fir_area_optimized" "fir_piplined"}

set tech_names {"45nm" "90nm" "180nm"}

array set lib_mapping {
    "slow"    "slow.lib"
    "typical" "typical.lib"
    "fast"    "fast.lib"
}
set lib_names {"slow" "typical" "fast"}

set fixed_period_ns 10.0

foreach des_dir $design_folders {
    
    set TOP_MODULE [lindex $design_mapping($des_dir) 0]
    set v_file     [lindex $design_mapping($des_dir) 1]
    set sdc_file   [lindex $design_mapping($des_dir) 2]
    
    if {![file exists $des_dir]} {
        puts ">>> WARNING: Cannot find the folder '$des_dir'."
        continue
    }
    
    cd $des_dir
    set_db init_hdl_search_path [pwd]
    
    foreach tech $tech_names {
        foreach lib_name $lib_names {
            
            set lib_filename $lib_mapping($lib_name)
            
            # =================================================================
            # CRITICAL FIX: FORCING THE ABSOLUTE PATH
            # This prevents Genus from caching and reusing the 45nm library!
            # =================================================================
            set absolute_lib_path "/home/install/FOUNDRY/digital/${tech}/dig/lib/${lib_filename}"
            
            if {[catch {set_db library $absolute_lib_path} err]} {
                puts ">>> CRITICAL WARNING: Could not load $absolute_lib_path!"
                puts ">>> Ensure the folder is named exactly '${tech}' on your server."
                continue
            }
            
            puts "\n---------------------------------------------------------------------"
            puts "Synthesizing: Design = $TOP_MODULE | Tech = $tech | Lib = $lib_name"
            puts "---------------------------------------------------------------------"
            
            set out_dir "${tech}/${lib_name}/output"
            file mkdir $out_dir/netlist
            file mkdir $out_dir/constraints
            file mkdir $out_dir/reports
            
            if {[catch {
                read_hdl $v_file
                elaborate $TOP_MODULE
                read_sdc $sdc_file
                
                catch { create_clock -name CLK -period $fixed_period_ns [get_ports clk] }
                
                set_db syn_generic_effort medium
                set_db syn_map_effort medium
                set_db syn_opt_effort medium
                
                syn_generic
                write_hdl > ${out_dir}/netlist/${TOP_MODULE}_generic.v
                
                syn_map
                write_hdl > ${out_dir}/netlist/${TOP_MODULE}_mapped.v
                
                syn_opt
                write_hdl > ${out_dir}/netlist/${TOP_MODULE}_opt.v
                write_sdc > ${out_dir}/constraints/${TOP_MODULE}_synth.sdc
                
                report_timing > ${out_dir}/reports/${TOP_MODULE}_timing.rpt
                report_power  > ${out_dir}/reports/${TOP_MODULE}_power.rpt
                report_area   > ${out_dir}/reports/${TOP_MODULE}_area.rpt
                report_gates  > ${out_dir}/reports/${TOP_MODULE}_gates.rpt
                report_qor    > ${out_dir}/reports/${TOP_MODULE}_qor.rpt
                
                delete_obj /designs/*
                
            } err]} {
                puts ">>> SYNTHESIS FAILED for $tech / $lib_name! Error: $err"
                catch { delete_obj /designs/* }
            }
        }
    }
    cd $base_dir
}

puts "\n================================================="
puts "ALL 27 RUNS ATTEMPTED WITH EXPLICIT LIBRARIES!"
puts "=================================================\n"
gui_show
