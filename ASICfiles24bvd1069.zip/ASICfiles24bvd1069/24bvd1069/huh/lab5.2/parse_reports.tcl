#!/usr/bin/env tclsh
# parse_reports.tcl - Styled report generator for gedit

set output_txt "synthesis_summary.txt"
set root_dir "."

proc find_files {dir pattern} {
    set files {}
    foreach item [glob -nocomplain -directory $dir *] {
        if {[file isdirectory $item]} {
            set files [concat $files [find_files $item $pattern]]
        } elseif {[string match $pattern [file tail $item]]} {
            lappend files $item
        }
    }
    return $files
}

proc extract_floats {line} {
    set numbers {}
    foreach token [split [string map {\t " " , " "} $line] " "] {
        set clean [string trim $token " ()"]
        if {[regexp {^-?[\d]+\.?[\d]*([eE][+-]?[\d]+)?$} $clean]} {
            lappend numbers $clean
        }
    }
    return $numbers
}

proc to_uW {val} {
    if {$val eq "N/A" || ![string is double -strict $val]} { return $val }
    return [format "%.2f" [expr {$val * 1e6}]]
}

set records {}
set power_reports [find_files $root_dir "*_power.rpt"]

foreach pwr_file $power_reports {
    set rpt_dir [file dirname $pwr_file]
    set path_split [file split $pwr_file]

    # Dynamically grab names from the strict folder structure: <design>/<lib>/<freq>/output/reports/
    set freq   [lindex $path_split end-3]
    set corner [lindex $path_split end-4]
    set arch   [lindex $path_split end-5]

    set area "N/A"; set insts "N/A"
    set wns "N/A"; set tns "N/A"
    set leakage "N/A"; set dynamic "N/A"; set total_pwr "N/A"

    # Parse Power
    if {[file exists $pwr_file]} {
        set fp [open $pwr_file "r"]
        while {[gets $fp line] >= 0} {
            set line_lower [string tolower $line]
            if {[string match "*fir_4tap*" $line_lower] || [string match "*total*" $line_lower]} {
                set nums [extract_floats $line]
                if {[llength $nums] >= 3} {
                    set leakage [lindex $nums end-2]
                    set dynamic [lindex $nums end-1]
                    set total_pwr [lindex $nums end]
                }
            }
        }
        close $fp
    }

    # Parse Area
    set area_files [glob -nocomplain "$rpt_dir/*area*.rpt"]
    if {[llength $area_files] > 0} {
        set fp [open [lindex $area_files 0] "r"]
        while {[gets $fp line] >= 0} {
            if {[regexp {^\s*([a-zA-Z0-9_]+)\s+(\d+)\s+([\d\.]+)\s+([\d\.]+)\s+([\d\.]+)} $line -> inst count c_area n_area t_area]} {
                if {$insts eq "N/A"} { set insts $count }
                if {$area eq "N/A"}  { set area [format "%.2f" $t_area] }
            }
        }
        close $fp
    }
    
    # Parse Timing (WNS / Slack)
    set timing_files [glob -nocomplain "$rpt_dir/*timing*.rpt"]
    if {[llength $timing_files] > 0} {
        set fp [open [lindex $timing_files 0] "r"]
        while {[gets $fp line] >= 0} {
            if {[regexp -nocase {Slack[^\d\+\-]*([+\-]?[0-9\.]+)} $line match val]} {
                set wns $val
            }
        }
        close $fp
    }

    lappend records [dict create arch $arch corner $corner freq $freq area $area insts $insts wns $wns tns $tns leakage [to_uW $leakage] dynamic [to_uW $dynamic] total [to_uW $total_pwr]]
}

# Output formatted text file
set fp [open $output_txt "w"]

puts $fp "╔══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╗"
puts $fp "║                                    CADENCE GENUS SYNTHESIS COMPARISON REPORT                                         ║"
puts $fp "╚══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╝"
puts $fp ""

# 1. Executive Comparison Table (Baseline @ typical / 1mhz)
puts $fp "┌──────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐"
puts $fp "│ EXECUTIVE SUMMARY (Baseline Corner: typical | Clock: 1mhz)                                                         │"
puts $fp "├─────────────────────────┬───────────────┬────────────┬──────────────────┬──────────────────┬─────────────────────────┤"
puts $fp "│ Architecture            │ Area (um2)    │ Instances  │ Leakage (uW)     │ Dynamic (uW)     │ Total Power (uW)        │"
puts $fp "├─────────────────────────┼───────────────┼────────────┼──────────────────┼──────────────────┼─────────────────────────┤"

foreach r $records {
    if {[dict get $r corner] eq "typical" && [dict get $r freq] eq "1mhz"} {
        puts $fp [format "│ %-23s │ %-13s │ %-10s │ %-16s │ %-16s │ %-23s │" \
            [dict get $r arch] [dict get $r area] [dict get $r insts] [dict get $r leakage] [dict get $r dynamic] [dict get $r total]]
    }
}
puts $fp "└─────────────────────────┴───────────────┴────────────┴──────────────────┴──────────────────┴─────────────────────────┘"
puts $fp ""

# 2. Detailed Breakdown Table
puts $fp "┌──────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐"
puts $fp "│ DETAILED CORNER & FREQUENCY COMPARISON                                                                               │"
puts $fp "├───────────────────┬──────────┬──────────┬───────────┬───────┬───────┬────────────────┬────────────────┬──────────────┤"
puts $fp "│ Architecture      │ Corner   │ Freq     │ Area(um2) │ Insts │ WNS   │ Leakage(uW)    │ Dynamic(uW)    │ Total(uW)    │"
puts $fp "├───────────────────┼──────────┼──────────┼───────────┼───────┼───────┼────────────────┼────────────────┼──────────────┤"

set last_arch ""
foreach r $records {
    set arch [dict get $r arch]
    if {$last_arch ne "" && $last_arch ne $arch} {
        puts $fp "├───────────────────┼──────────┼──────────┼───────────┼───────┼───────┼────────────────┼────────────────┼──────────────┤"
    }
    set last_arch $arch

    puts $fp [format "│ %-17s │ %-8s │ %-8s │ %-9s │ %-5s │ %-5s │ %-14s │ %-14s │ %-12s │" \
        $arch [dict get $r corner] [dict get $r freq] [dict get $r area] [dict get $r insts] [dict get $r wns] [dict get $r leakage] [dict get $r dynamic] [dict get $r total]]
}
puts $fp "└───────────────────┴──────────┴──────────┴───────────┴───────┴───────┴────────────────┴────────────────┴──────────────┘"

close $fp
puts "\nReport successfully generated and saved to $output_txt\n"
