module fir_4tap_shared_mult (
    input  wire                    clk,
    input  wire                    rst,
    input  wire                    sample_valid,
    output wire                    sample_ready,
    input  wire signed [7:0]       xin,
    output reg                     yout_valid,
    output reg signed [17:0]       yout
);

    // Delay-line registers
    reg signed [7:0] x1, x2, x3;
    
    // Always ready to accept a new sample
    assign sample_ready = 1'b1;

    // Algebraic Optimization to share adders and eliminate multipliers
    // y[n] = 4*(xin + x1) - (x1 + x2) - 2*x3
    wire signed [8:0] sum_A = xin + x1;
    wire signed [8:0] sum_B = x1 + x2;
    wire signed [17:0] next_yout = (sum_A <<< 2) - sum_B - (x3 <<< 1);

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            x1         <= 8'sd0;
            x2         <= 8'sd0;
            x3         <= 8'sd0;
            yout       <= 18'sd0;
            yout_valid <= 1'b0;
        end else begin
            // Only pulse yout_valid if we actually received a valid sample
            yout_valid <= sample_valid;
            
            if (sample_valid) begin
                yout <= next_yout;
                
                // Shift delay line
                x3   <= x2;
                x2   <= x1;
                x1   <= xin;
            end
        end
    end

endmodule
