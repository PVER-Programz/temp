if {![namespace exists ::IMEX]} { namespace eval ::IMEX {} }
set ::IMEX::dataVar [file dirname [file normalize [info script]]]
set ::IMEX::libVar ${::IMEX::dataVar}/libs

create_library_set -name MAXT\
   -timing\
    [list ${::IMEX::libVar}/mmmc/slow.lib]
create_library_set -name MINT\
   -timing\
    [list ${::IMEX::libVar}/mmmc/fast.lib]
create_rc_corner -name default_rc_corner\
   -preRoute_res 1\
   -postRoute_res 1\
   -preRoute_cap 1\
   -postRoute_cap 1\
   -postRoute_xcap 1\
   -preRoute_clkres 0\
   -preRoute_clkcap 0
create_delay_corner -name WORSTC\
   -library_set MAXT
create_delay_corner -name BESTC\
   -library_set MINT
create_constraint_mode -name CONSTRAN\
   -sdc_files\
    [list /dev/null]
create_analysis_view -name worst -constraint_mode CONSTRAN -delay_corner WORSTC
create_analysis_view -name best -constraint_mode CONSTRAN -delay_corner BESTC
set_analysis_view -setup [list worst] -hold [list best]
