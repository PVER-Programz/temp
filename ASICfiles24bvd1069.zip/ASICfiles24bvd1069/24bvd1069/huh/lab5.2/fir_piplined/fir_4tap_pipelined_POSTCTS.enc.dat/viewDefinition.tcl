if {![namespace exists ::IMEX]} { namespace eval ::IMEX {} }
set ::IMEX::dataVar [file dirname [file normalize [info script]]]
set ::IMEX::libVar ${::IMEX::dataVar}/libs

create_library_set -name MINTIM\
   -timing\
    [list ${::IMEX::libVar}/mmmc/fast.lib]
create_library_set -name MAXTIME\
   -timing\
    [list ${::IMEX::libVar}/mmmc/slow.lib]
create_rc_corner -name default_rc_corner\
   -preRoute_res 1\
   -postRoute_res 1\
   -preRoute_cap 1\
   -postRoute_cap 1\
   -postRoute_xcap 1\
   -preRoute_clkres 0\
   -preRoute_clkcap 0
create_delay_corner -name WORSTC\
   -library_set MAXTIME
create_delay_corner -name BEESTC\
   -library_set MINTIM
create_constraint_mode -name CONSTA\
   -sdc_files\
    [list ${::IMEX::libVar}/mmmc/fir_4tap_pipelined_synth.sdc]
create_analysis_view -name BEST -constraint_mode CONSTA -delay_corner BEESTC
create_analysis_view -name WORST -constraint_mode CONSTA -delay_corner WORSTC
set_analysis_view -setup [list WORST] -hold [list WORST]
