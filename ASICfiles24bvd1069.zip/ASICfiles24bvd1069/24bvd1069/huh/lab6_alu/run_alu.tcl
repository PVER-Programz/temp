# ====================================================================
# Cadence Genus Synthesis Script for Sequential ALU
# Stages: Generic, Mapped, Optimized
# ====================================================================

set_db init_lib_search_path /home/install/FOUNDRY/digital/90nm/dig/lib
set_db library slow.lib

set TOP_MODULE "alu_4bit_seq"

file mkdir reports/generic
file mkdir reports/mapped
file mkdir reports/optimized

read_hdl alu_4bit_seq.v
elaborate $TOP_MODULE
read_sdc alu_4bit_seq.sdc

# --- STAGE 1: GENERIC SYNTHESIS ---
set_db syn_generic_effort medium
syn_generic

report_timing > reports/generic/${TOP_MODULE}_timing.rpt
report_area   > reports/generic/${TOP_MODULE}_area.rpt
report_power  > reports/generic/${TOP_MODULE}_power.rpt
report_qor    > reports/generic/${TOP_MODULE}_qor.rpt

# --- STAGE 2: MAPPED SYNTHESIS ---
set_db syn_map_effort medium
syn_map

report_timing > reports/mapped/${TOP_MODULE}_timing.rpt
report_area   > reports/mapped/${TOP_MODULE}_area.rpt
report_power  > reports/mapped/${TOP_MODULE}_power.rpt
report_qor    > reports/mapped/${TOP_MODULE}_qor.rpt

# --- STAGE 3: OPTIMIZED SYNTHESIS ---
set_db syn_opt_effort medium
syn_opt

report_timing > reports/optimized/${TOP_MODULE}_timing.rpt
report_area   > reports/optimized/${TOP_MODULE}_area.rpt
report_power  > reports/optimized/${TOP_MODULE}_power.rpt
report_qor    > reports/optimized/${TOP_MODULE}_qor.rpt

puts "\n================================================="
puts "ALU MULTI-STAGE SYNTHESIS COMPLETE!"
puts "=================================================\n"
gui_show
