# Cadence Genus(TM) Synthesis Solution, Version 21.14-s082_1, built Jun 23 2022 14:32:08

# Date: Thu Sep 03 15:56:48 2026
# Host: cad312vitcc.vit.ac.in (x86_64 w/Linux 4.18.0-553.150.1.el8_10.x86_64) (16cores*64cpus*2physical cpus*INTEL(R) XEON(R) GOLD 6526Y 38400KB)
# OS:   Red Hat Enterprise Linux release 8.10 (Ootpa)

source run_alu.tcl
module alu_4bit_seq (
input  wire        clk,
input  wire        rst,
input  wire [2:0]  opcode,
input  wire [3:0]  A,
input  wire [3:0]  B,
output reg  [3:0]  ALU_Out,
output reg         CarryOut
);
always @(posedge clk or posedge rst) begin
if (rst) begin
ALU_Out  <= 4'b0000;
CarryOut <= 1'b0;
end else begin
case (opcode)
3'b000: begin // ADD
{CarryOut, ALU_Out} <= A + B;
end
3'b001: begin // SUB
{CarryOut, ALU_Out} <= A - B;
end
3'b010: begin // AND
ALU_Out  <= A & B;
CarryOut <= 1'b0;
end
3'b011: begin // OR
ALU_Out  <= A | B;
CarryOut <= 1'b0;
end
3'b100: begin // XOR
ALU_Out  <= A ^ B;
CarryOut <= 1'b0;
end
3'b101: begin // NOT A
ALU_Out  <= ~A;
CarryOut <= 1'b0;
end
3'b110: begin // Shift Left A by 1
ALU_Out  <= {A[2:0], 1'b0};
CarryOut <= A[3];
end
default: begin // 3'b111: Shift Right A by 1
ALU_Out  <= {1'b0, A[3:1]};
CarryOut <= A[0];
end
endcase
end
end
endmodule
exit
