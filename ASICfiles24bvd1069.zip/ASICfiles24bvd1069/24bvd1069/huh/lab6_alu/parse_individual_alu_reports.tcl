#!/usr/bin/env tclsh
# ====================================================================
# Individual Stage Report Extractor for 4-bit Sequential ALU
# Generates separate summary files:
#   - alu_generic_summary.txt
#   - alu_mapped_summary.txt
#   - alu_optimized_summary.txt
# RUN COMMAND: tclsh parse_individual_alu_reports.tcl
# ====================================================================

set top_module "alu_4bit_seq"
set stages {"generic" "mapped" "optimized"}

proc extract_floats {line} {
    set numbers {}
    foreach token [split [string map {\t " " , " "} $line] " "] {
        set clean [string trim $token " ()"]
        if {[regexp {^-?[\d]+\.?[\d]*([eE][+-]?[\d]+)?$} $clean]} {
            lappend numbers $clean
        }
    }
    return $numbers
}

proc format_pwr {val} {
    if {$val eq "N/A"} { return $val }
    if {[catch {set scaled [expr {$val * 1e6}]}]} { return $val }
    return [format "%.4f" $scaled]
}

foreach stage $stages {
    set rpt_dir "reports/$stage"
    set stage_upper [string toupper $stage]
    set out_filename "alu_${stage}_summary.txt"

    set tot_area "N/A"; set cell_area "N/A"; set gate_cnt "N/A"
    set seq_inst "N/A"; set comb_inst "N/A"; set tot_inst "N/A"
    set delay "N/A";    set wns "N/A";       set tns "N/A"
    set leak_pwr "N/A"; set dyn_pwr "N/A";   set tot_pwr "N/A"

    # 1. Parse QoR Report
    set qor_file "$rpt_dir/${top_module}_qor.rpt"
    if {[file exists $qor_file]} {
        set fp [open $qor_file "r"]
        while {[gets $fp line] >= 0} {
            if {[regexp -nocase {Total Area[^\d]*([0-9\.]+)} $line -> val]} { set tot_area $val }
            if {[regexp -nocase {Cell Area[^\d]*([0-9\.]+)} $line -> val] && $cell_area eq "N/A"} { set cell_area $val }
            if {[regexp -nocase {Gate Count[^\d]*([0-9\.]+)} $line -> val]} { set gate_cnt $val }
            if {[regexp -nocase {Sequential Instance Count[^\d]*([0-9\.]+)} $line -> val]} { set seq_inst $val }
            if {[regexp -nocase {Combinational Instance Count[^\d]*([0-9\.]+)} $line -> val]} { set comb_inst $val }
            if {[regexp -nocase {Leaf Instance Count[^\d]*([0-9\.]+)} $line -> val]} { set tot_inst $val }
            if {[regexp -nocase {Worst Negative Slack[^\d\+\-]*([+\-]?[0-9\.]+)} $line -> val]} { set wns $val }
            if {[regexp -nocase {Total Negative Slack[^\d\+\-]*([+\-]?[0-9\.]+)} $line -> val]} { set tns $val }
            if {[regexp -nocase {^\s*default\s+[\+\-]?[0-9\.]+\s+([+\-]?[0-9\.]+)} $line -> val]} { set tns $val }
        }
        close $fp
    }

    # 2. Parse Area Report Fallback
    set area_file "$rpt_dir/${top_module}_area.rpt"
    if {[file exists $area_file]} {
        set fp [open $area_file "r"]
        while {[gets $fp line] >= 0} {
            if {[regexp {^\s*([a-zA-Z0-9_]+)\s+(\d+)\s+([\d\.]+)\s+([\d\.]+)\s+([\d\.]+)} $line -> inst count c_area n_area t_area]} {
                if {$inst eq $top_module} {
                    if {$tot_inst eq "N/A"}  { set tot_inst $count }
                    if {$tot_area eq "N/A"}  { set tot_area $t_area }
                    if {$cell_area eq "N/A"} { set cell_area $c_area }
                }
            }
        }
        close $fp
    }

    if {$gate_cnt eq "N/A" && $tot_inst ne "N/A"} { set gate_cnt $tot_inst }

    # 3. Parse Timing & Delay
    set timing_file "$rpt_dir/${top_module}_timing.rpt"
    if {[file exists $timing_file]} {
        set fp [open $timing_file "r"]
        while {[gets $fp line] >= 0} {
            if {[regexp -nocase {Slack[^\d\+\-]*([+\-]?[0-9\.]+)} $line match val]} {
                if {$wns eq "N/A"} { set wns $val }
            }
            if {[regexp -nocase {Data Path[^\d]*([0-9\.]+)} $line match val]} {
                set delay $val
            }
        }
        close $fp
    }

    # Fallback Data Path Delay: Period (10000 ps) - Uncertainty (200 ps) - WNS
    if {$delay eq "N/A" && $wns ne "N/A"} {
        set fallback [expr {10000.0 - 200.0 - $wns}]
        set delay [format "%.1f" $fallback]
    }

    if {$tns eq "N/A" && $wns ne "N/A" && $wns >= 0} {
        set tns "0.0"
    }

    # 4. Parse Power Report
    set power_file "$rpt_dir/${top_module}_power.rpt"
    if {[file exists $power_file]} {
        set fp [open $power_file "r"]
        while {[gets $fp line] >= 0} {
            set line_lower [string tolower $line]
            if {[string match "*$top_module*" $line_lower] || [string match "*total*" $line_lower]} {
                set nums [extract_floats $line]
                if {[llength $nums] >= 3} {
                    set leak_pwr [format_pwr [lindex $nums end-2]]
                    set dyn_pwr  [format_pwr [lindex $nums end-1]]
                    set tot_pwr  [format_pwr [lindex $nums end]]
                }
            }
        }
        close $fp
    }

    # Write Individual Stage File
    set fp_out [open $out_filename "w"]

    puts $fp_out "╔══════════════════════════════════════════════════════════════════════════════════════╗"
    puts $fp_out [format "║      CADENCE GENUS SYNTHESIS STAGE REPORT: %-41s ║" "$stage_upper STAGE"]
    puts $fp_out "╚══════════════════════════════════════════════════════════════════════════════════════╝"
    puts $fp_out ""
    puts $fp_out [format "  Design Name        : %s" $top_module]
    puts $fp_out [format "  Synthesis Stage    : %s" $stage_upper]
    puts $fp_out [format "  Target Clock       : 100 MHz (Period: 10.0 ns)"]
    puts $fp_out ""
    puts $fp_out "┌──────────────────────────────────────────────────────────────────────────────────────┐"
    puts $fp_out "│ 1. AREA & INSTANCE METRICS                                                           │"
    puts $fp_out "├──────────────────────────────────────────────────────┬───────────────────────────────┤"
    puts $fp_out [format "│  %-51s │ %-29s │" "Total Area (um²)" $tot_area]
    puts $fp_out [format "│  %-51s │ %-29s │" "Cell Area (um²)" $cell_area]
    puts $fp_out [format "│  %-51s │ %-29s │" "Estimated Gate Count" $gate_cnt]
    puts $fp_out [format "│  %-51s │ %-29s │" "Sequential Leaf Instances (Registers/DFFs)" $seq_inst]
    puts $fp_out [format "│  %-51s │ %-29s │" "Combinational Leaf Instances" $comb_inst]
    puts $fp_out [format "│  %-51s │ %-29s │" "Total Leaf Instances" $tot_inst]
    puts $fp_out "└──────────────────────────────────────────────────────┴───────────────────────────────┘"
    puts $fp_out ""
    puts $fp_out "┌──────────────────────────────────────────────────────────────────────────────────────┐"
    puts $fp_out "│ 2. TIMING QUALITY & DELAY                                                            │"
    puts $fp_out "├──────────────────────────────────────────────────────┬───────────────────────────────┤"
    puts $fp_out [format "│  %-51s │ %-29s │" "Critical Path Delay (ps)" $delay]
    puts $fp_out [format "│  %-51s │ %-29s │" "Worst Negative Slack - WNS (ps)" $wns]
    puts $fp_out [format "│  %-51s │ %-29s │" "Total Negative Slack - TNS (ps)" $tns]
    puts $fp_out "└──────────────────────────────────────────────────────┴───────────────────────────────┘"
    puts $fp_out ""
    puts $fp_out "┌──────────────────────────────────────────────────────────────────────────────────────┐"
    puts $fp_out "│ 3. POWER BREAKDOWN                                                                   │"
    puts $fp_out "├──────────────────────────────────────────────────────┬───────────────────────────────┤"
    puts $fp_out [format "│  %-51s │ %-29s │" "Leakage Power (uW)" $leak_pwr]
    puts $fp_out [format "│  %-51s │ %-29s │" "Dynamic Power (uW)" $dyn_pwr]
    puts $fp_out [format "│  %-51s │ %-29s │" "Total Power (uW)" $tot_pwr]
    puts $fp_out "└──────────────────────────────────────────────────────┴───────────────────────────────┘"
    
    close $fp_out
    puts "Generated: $out_filename"
}

puts "\nAll three individual synthesis reports generated successfully."
