
//input ports
add mapped point clk clk -type PI PI
add mapped point rst rst -type PI PI
add mapped point opcode[2] opcode[2] -type PI PI
add mapped point opcode[1] opcode[1] -type PI PI
add mapped point opcode[0] opcode[0] -type PI PI
add mapped point A[3] A[3] -type PI PI
add mapped point A[2] A[2] -type PI PI
add mapped point A[1] A[1] -type PI PI
add mapped point A[0] A[0] -type PI PI
add mapped point B[3] B[3] -type PI PI
add mapped point B[2] B[2] -type PI PI
add mapped point B[1] B[1] -type PI PI
add mapped point B[0] B[0] -type PI PI

//output ports
add mapped point ALU_Out[3] ALU_Out[3] -type PO PO
add mapped point ALU_Out[2] ALU_Out[2] -type PO PO
add mapped point ALU_Out[1] ALU_Out[1] -type PO PO
add mapped point ALU_Out[0] ALU_Out[0] -type PO PO
add mapped point CarryOut CarryOut -type PO PO

//inout ports




//Sequential Pins
add mapped point CarryOut/q CarryOut_reg/Q -type DFF DFF
add mapped point ALU_Out[3]/q ALU_Out_reg[3]/Q -type DFF DFF
add mapped point ALU_Out[2]/q ALU_Out_reg[2]/Q -type DFF DFF
add mapped point ALU_Out[1]/q ALU_Out_reg[1]/Q -type DFF DFF
add mapped point ALU_Out[0]/q ALU_Out_reg[0]/Q -type DFF DFF



//Black Boxes



//Empty Modules as Blackboxes
