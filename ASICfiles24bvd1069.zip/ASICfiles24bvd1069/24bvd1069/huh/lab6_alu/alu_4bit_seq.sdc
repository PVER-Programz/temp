# SDC Constraints for 4-bit Sequential ALU
# Clock frequency: 100 MHz (10.0 ns period)

# 1. Primary Clock Definition
create_clock -name clk -period 10.0 [get_ports clk]

# Clock Tree Modeling
set_clock_uncertainty 0.2 [get_clocks clk]
set_clock_transition  0.1 [get_clocks clk]

# 2. Input/Output Delays (20% of clock period)
set_input_delay  2.0 -clock clk [remove_from_collection [all_inputs] [get_ports clk]]
set_output_delay 2.0 -clock clk [all_outputs]

# 3. Input Slew and Output Load
set_input_transition 0.1 [remove_from_collection [all_inputs] [get_ports clk]]
set_load 0.05 [all_outputs]

# 4. Asynchronous Reset
set_false_path -from [get_ports rst]
