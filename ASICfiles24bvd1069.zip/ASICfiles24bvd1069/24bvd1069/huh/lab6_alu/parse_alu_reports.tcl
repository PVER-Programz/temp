#!/usr/bin/env tclsh
# ====================================================================
# Comprehensive Extractor Script for 4-bit Sequential ALU
# RUN COMMAND: tclsh parse_alu_reports.tcl
# ====================================================================

set output_txt "alu_detailed_summary.txt"
set top_module "alu_4bit_seq"
set stages {"generic" "mapped" "optimized"}

proc extract_floats {line} {
    set numbers {}
    foreach token [split [string map {\t " " , " "} $line] " "] {
        set clean [string trim $token " ()"]
        if {[regexp {^-?[\d]+\.?[\d]*([eE][+-]?[\d]+)?$} $clean]} {
            lappend numbers $clean
        }
    }
    return $numbers
}

proc format_pwr {val} {
    if {$val eq "N/A"} { return $val }
    if {[catch {set scaled [expr {$val * 1e6}]}]} { return $val }
    return [format "%.3f" $scaled]
}

set txt_out [open $output_txt "w"]

set hr_top  "╔══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╗"
set title   "║                                            4-BIT SEQUENTIAL ALU SYNTHESIS REPORT (GENERIC VS MAPPED VS OPT)                                      ║"
set hr_mid1 "╚══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╝"
set hr_mid2 "┌─────────────┬────────────────────────────────────────────────────────────────┬─────────────────────────────────┬───────────────────────────────────┐"
set header1 "│             │                          AREA METRICS                          │     TIMING QUALITY & DELAY      │        POWER BREAKDOWN (uW)       │"
set hr_mid3 "│ Synthesis   ├────────────┬────────────┬────────────┬────────────┬────────────┼───────────┬──────────┬──────────┼───────────┬───────────┬───────────┤"
set header2 "│ Stage       │ Total Area │ Cell Area  │ Gate Count │ Seq Inst   │ Comb Inst  │ Delay(ps) │ WNS(ps)  │ TNS(ps)  │ Leakage   │ Dynamic   │ Total     │"
set hr_mid4 "├─────────────┼────────────┼────────────┼────────────┼────────────┼────────────┼───────────┼──────────┼──────────┼───────────┼───────────┼───────────┤"
set hr_bot  "└─────────────┴────────────┴────────────┴────────────┴────────────┴────────────┴───────────┴──────────┴──────────┴───────────┴───────────┴───────────┘"

foreach line [list $hr_top $title $hr_mid1 "" $hr_mid2 $header1 $hr_mid3 $header2 $hr_mid4] {
    puts $line
    puts $txt_out $line
}

foreach stage $stages {
    set rpt_dir "reports/$stage"
    
    set tot_area "N/A"; set cell_area "N/A"; set gate_cnt "N/A"
    set seq_inst "N/A"; set comb_inst "N/A"; set tot_inst "N/A"
    set delay "N/A";    set wns "N/A";       set tns "N/A"
    set leak_pwr "N/A"; set dyn_pwr "N/A";   set tot_pwr "N/A"

    # 1. Parse QoR Report
    set qor_file "$rpt_dir/${top_module}_qor.rpt"
    if {[file exists $qor_file]} {
        set fp [open $qor_file "r"]
        while {[gets $fp line] >= 0} {
            if {[regexp -nocase {Total Area[^\d]*([0-9\.]+)} $line -> val]} { set tot_area $val }
            if {[regexp -nocase {Cell Area[^\d]*([0-9\.]+)} $line -> val] && $cell_area eq "N/A"} { set cell_area $val }
            if {[regexp -nocase {Gate Count[^\d]*([0-9\.]+)} $line -> val]} { set gate_cnt $val }
            if {[regexp -nocase {Sequential Instance Count[^\d]*([0-9\.]+)} $line -> val]} { set seq_inst $val }
            if {[regexp -nocase {Combinational Instance Count[^\d]*([0-9\.]+)} $line -> val]} { set comb_inst $val }
            if {[regexp -nocase {Leaf Instance Count[^\d]*([0-9\.]+)} $line -> val]} { set tot_inst $val }
            if {[regexp -nocase {Worst Negative Slack[^\d\+\-]*([+\-]?[0-9\.]+)} $line -> val]} { set wns $val }
            if {[regexp -nocase {Total Negative Slack[^\d\+\-]*([+\-]?[0-9\.]+)} $line -> val]} { set tns $val }
            if {[regexp -nocase {^\s*default\s+[\+\-]?[0-9\.]+\s+([+\-]?[0-9\.]+)} $line -> val]} { set tns $val }
        }
        close $fp
    }

    # 2. Parse Area Report fallback
    set area_file "$rpt_dir/${top_module}_area.rpt"
    if {[file exists $area_file]} {
        set fp [open $area_file "r"]
        while {[gets $fp line] >= 0} {
            if {[regexp {^\s*([a-zA-Z0-9_]+)\s+(\d+)\s+([\d\.]+)\s+([\d\.]+)\s+([\d\.]+)} $line -> inst count c_area n_area t_area]} {
                if {$inst eq $top_module} {
                    if {$tot_inst eq "N/A"}  { set tot_inst $count }
                    if {$tot_area eq "N/A"}  { set tot_area $t_area }
                    if {$cell_area eq "N/A"} { set cell_area $c_area }
                }
            }
        }
        close $fp
    }

    if {$gate_cnt eq "N/A" && $tot_inst ne "N/A"} { set gate_cnt $tot_inst }

    # 3. Parse Timing & Delay
    set timing_file "$rpt_dir/${top_module}_timing.rpt"
    if {[file exists $timing_file]} {
        set fp [open $timing_file "r"]
        while {[gets $fp line] >= 0} {
            if {[regexp -nocase {Slack[^\d\+\-]*([+\-]?[0-9\.]+)} $line match val]} {
                if {$wns eq "N/A"} { set wns $val }
            }
            if {[regexp -nocase {Data Path[^\d]*([0-9\.]+)} $line match val]} {
                set delay $val
            }
        }
        close $fp
    }

    # Fallback Data Path Delay: Period(10000) - Uncertainty(200) - WNS
    if {$delay eq "N/A" && $wns ne "N/A"} {
        set fallback [expr {10000.0 - 200.0 - $wns}]
        set delay [format "%.1f" $fallback]
    }

    if {$tns eq "N/A" && $wns ne "N/A" && $wns >= 0} {
        set tns "0.0"
    }

    # 4. Parse Power
    set power_file "$rpt_dir/${top_module}_power.rpt"
    if {[file exists $power_file]} {
        set fp [open $power_file "r"]
        while {[gets $fp line] >= 0} {
            set line_lower [string tolower $line]
            if {[string match "*$top_module*" $line_lower] || [string match "*total*" $line_lower]} {
                set nums [extract_floats $line]
                if {[llength $nums] >= 3} {
                    set leak_pwr [format_pwr [lindex $nums end-2]]
                    set dyn_pwr  [format_pwr [lindex $nums end-1]]
                    set tot_pwr  [format_pwr [lindex $nums end]]
                }
            }
        }
        close $fp
    }

    set row [format "│ %-11s │ %-10s │ %-10s │ %-10s │ %-10s │ %-10s │ %-9s │ %-8s │ %-8s │ %-9s │ %-9s │ %-9s │" \
        $stage $tot_area $cell_area $gate_cnt $seq_inst $comb_inst $delay $wns $tns $leak_pwr $dyn_pwr $tot_pwr]
    
    puts $row
    puts $txt_out $row
}

puts $hr_bot
puts $txt_out $hr_bot

close $txt_out
puts "\nReport successfully generated and saved to $output_txt\n"
