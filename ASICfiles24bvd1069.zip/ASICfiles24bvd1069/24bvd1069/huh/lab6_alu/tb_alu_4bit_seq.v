`timescale 1ns / 1ps

module tb_alu_4bit_seq;
    reg        clk;
    reg        rst;
    reg  [2:0] opcode;
    reg  [3:0] A;
    reg  [3:0] B;
    wire [3:0] ALU_Out;
    wire       CarryOut;

    alu_4bit_seq uut (
        .clk(clk),
        .rst(rst),
        .opcode(opcode),
        .A(A),
        .B(B),
        .ALU_Out(ALU_Out),
        .CarryOut(CarryOut)
    );

    // 100 MHz clock (10 ns period)
    always #5 clk = ~clk;

    initial begin
        clk = 0;
        rst = 1;
        opcode = 3'b000;
        A = 4'b0000;
        B = 4'b0000;

        #15;
        rst = 0;

        // Opcode 0: ADD (7 + 5 = 12)
        @(posedge clk);
        opcode = 3'b000; A = 4'd7; B = 4'd5;

        // Opcode 0: ADD with Carry (14 + 3 = 17 -> Sum 1, Carry 1)
        @(posedge clk);
        opcode = 3'b000; A = 4'd14; B = 4'd3;

        // Opcode 1: SUB (9 - 4 = 5)
        @(posedge clk);
        opcode = 3'b001; A = 4'd9; B = 4'd4;

        // Opcode 2: AND (1010 & 1100 = 1000)
        @(posedge clk);
        opcode = 3'b010; A = 4'b1010; B = 4'b1100;

        // Opcode 4: XOR (1010 ^ 1100 = 0110)
        @(posedge clk);
        opcode = 3'b100; A = 4'b1010; B = 4'b1100;

        // Opcode 6: Shift Left (1011 << 1 = 0110, Carry = 1)
        @(posedge clk);
        opcode = 3'b110; A = 4'b1011;

        @(posedge clk);
        #10;
        $finish;
    end
endmodule
