# SDC Constraints for 4-bit Combinational RCA
# Using a Virtual Clock (vclk) with a 10ns period

# 1. Virtual Clock (No port attached)
create_clock -name vclk -period 10.0

# 2. Input and Output Delays (constrained relative to the virtual clock)
set_input_delay  2.0 -clock vclk [all_inputs]
set_output_delay 2.0 -clock vclk [all_outputs]

# 3. Input Transition (Slew)
set_input_transition 0.1 [all_inputs]

# 4. Output Load
set_load 0.05 [all_outputs]
