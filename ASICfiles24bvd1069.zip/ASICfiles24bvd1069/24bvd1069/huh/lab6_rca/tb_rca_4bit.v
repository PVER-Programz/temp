module tb_rca_4bit;
    reg [3:0] A, B;
    reg Cin;
    wire [3:0] Sum;
    wire Cout;

    // Instantiate the RCA
    rca_4bit uut (
        .A(A), .B(B), .Cin(Cin), .Sum(Sum), .Cout(Cout)
    );

    initial begin
        $display("Time\t A    B    Cin | Sum  Cout");
        $monitor("%0t\t %b %b  %b  | %b %b", $time, A, B, Cin, Sum, Cout);
        
        // Test Cases
        A = 4'b0000; B = 4'b0000; Cin = 0; #10;
        A = 4'b0101; B = 4'b0010; Cin = 0; #10; // 5 + 2 = 7
        A = 4'b1111; B = 4'b0001; Cin = 0; #10; // 15 + 1 = 16 (Sum=0, Cout=1)
        A = 4'b0111; B = 4'b0111; Cin = 1; #10; // 7 + 7 + 1 = 15
        
        $finish;
    end
endmodule
