// 1-bit Full Adder (Structural)
module full_adder (
    input a, b, cin,
    output sum, cout
);
    wire w1, w2, w3;
    
    // Sum logic: sum = a XOR b XOR cin
    xor (w1, a, b);
    xor (sum, w1, cin);
    
    // Carry logic: cout = (a AND b) OR (cin AND (a XOR b))
    and (w2, w1, cin);
    and (w3, a, b);
    or  (cout, w2, w3);
endmodule

// 4-bit Ripple Carry Adder (Structural)
module rca_4bit (
    input  [3:0] A,
    input  [3:0] B,
    input        Cin,
    output [3:0] Sum,
    output       Cout
);
    wire c1, c2, c3;
    
    // Instantiating 4 Full Adders in a chain
    full_adder fa0 (.a(A[0]), .b(B[0]), .cin(Cin), .sum(Sum[0]), .cout(c1));
    full_adder fa1 (.a(A[1]), .b(B[1]), .cin(c1),  .sum(Sum[1]), .cout(c2));
    full_adder fa2 (.a(A[2]), .b(B[2]), .cin(c2),  .sum(Sum[2]), .cout(c3));
    full_adder fa3 (.a(A[3]), .b(B[3]), .cin(c3),  .sum(Sum[3]), .cout(Cout));

endmodule
