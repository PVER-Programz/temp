#!/usr/bin/env tclsh
# ====================================================================
# Comprehensive Master Extractor Script for 4-bit RCA
# Includes Area, Gate Count, Leaf/Comb Instances, Delay, WNS, TNS, & Power
# RUN COMMAND: tclsh parse_rca_reports.tcl
# ====================================================================

set output_txt "rca_detailed_summary.txt"
set top_module "rca_4bit"
set stages {"generic" "mapped" "optimized"}

# Hunts down floating point numbers
proc extract_floats {line} {
    set numbers {}
    foreach token [split [string map {\t " " , " "} $line] " "] {
        set clean [string trim $token " ()"]
        if {[regexp {^-?[\d]+\.?[\d]*([eE][+-]?[\d]+)?$} $clean]} {
            lappend numbers $clean
        }
    }
    return $numbers
}

# Converts scientific notation power (e.g., 1.802e-06) into readable microwatts
proc format_pwr {val} {
    if {$val eq "N/A"} { return $val }
    if {[catch {set scaled [expr {$val * 1e6}]}]} { return $val }
    return [format "%.3f" $scaled]
}

set txt_out [open $output_txt "w"]

# --------------------------------------------------------------------
# TABLE HEADER GENERATION (150 Chars Wide - Mathematically Aligned)
# --------------------------------------------------------------------
set hr_top    "╔══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╗"
set title     "║                                             4-BIT RCA COMPREHENSIVE MULTI-STAGE SYNTHESIS REPORT                                                 ║"
set hr_mid1   "╚══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╝"
set hr_mid2   "┌─────────────┬────────────────────────────────────────────────────────────────┬─────────────────────────────────┬───────────────────────────────────┐"
set header1   "│             │                          AREA METRICS                          │     TIMING QUALITY & DELAY      │        POWER BREAKDOWN (uW)       │"
set hr_mid3   "│ Synthesis   ├────────────┬────────────┬────────────┬────────────┬────────────┼───────────┬──────────┬──────────┼───────────┬───────────┬───────────┤"
set header2   "│ Stage       │ Total Area │ Cell Area  │ Gate Count │ Leaf Inst  │ Comb Inst  │ Delay(ps) │ WNS(ps)  │ TNS(ps)  │ Leakage   │ Dynamic   │ Total     │"
set hr_mid4   "├─────────────┼────────────┼────────────┼────────────┼────────────┼────────────┼───────────┼──────────┼──────────┼───────────┼───────────┼───────────┤"
set hr_bot    "└─────────────┴────────────┴────────────┴────────────┴────────────┴────────────┴───────────┴──────────┴──────────┴───────────┴───────────┴───────────┘"

# Print headers
foreach line [list $hr_top $title $hr_mid1 "" $hr_mid2 $header1 $hr_mid3 $header2 $hr_mid4] {
    puts $line
    puts $txt_out $line
}

# --------------------------------------------------------------------
# DATA EXTRACTION LOOP
# --------------------------------------------------------------------
foreach stage $stages {
    set rpt_dir "reports/$stage"
    
    set tot_area "N/A"; set cell_area "N/A"; set gate_cnt "N/A"
    set tot_inst "N/A"; set comb_inst "N/A"
    set delay "N/A";    set wns "N/A";       set tns "N/A"
    set leak_pwr "N/A"; set dyn_pwr "N/A";   set tot_pwr "N/A"

    # 1. Parse QoR Report
    set qor_file "$rpt_dir/${top_module}_qor.rpt"
    if {[file exists $qor_file]} {
        set fp [open $qor_file "r"]
        while {[gets $fp line] >= 0} {
            if {[regexp -nocase {Total Area[^\d]*([0-9\.]+)} $line -> val]} { set tot_area $val }
            if {[regexp -nocase {Cell Area[^\d]*([0-9\.]+)} $line -> val] && $cell_area eq "N/A"} { set cell_area $val }
            if {[regexp -nocase {Gate Count[^\d]*([0-9\.]+)} $line -> val]} { set gate_cnt $val }
            if {[regexp -nocase {Total Number of Cells[^\d]*([0-9\.]+)} $line -> val] && $gate_cnt eq "N/A"} { set gate_cnt $val }
            if {[regexp -nocase {Leaf Instance Count[^\d]*([0-9\.]+)} $line -> val]} { set tot_inst $val }
            if {[regexp -nocase {Instance Count[^\d]*([0-9\.]+)} $line -> val] && $tot_inst eq "N/A"} { set tot_inst $val }
            if {[regexp -nocase {Combinational Instance Count[^\d]*([0-9\.]+)} $line -> val]} { set comb_inst $val }
            if {[regexp -nocase {Worst Negative Slack[^\d\+\-]*([+\-]?[0-9\.]+)} $line -> val]} { set wns $val }
            if {[regexp -nocase {Total Negative Slack[^\d\+\-]*([+\-]?[0-9\.]+)} $line -> val]} { set tns $val }
            if {[regexp -nocase {^\s*default\s+[\+\-]?[0-9\.]+\s+([+\-]?[0-9\.]+)} $line -> val]} { set tns $val }
        }
        close $fp
    }

    # 2. Parse Area Report (Safe Regex Extraction)
    set area_file "$rpt_dir/${top_module}_area.rpt"
    if {[file exists $area_file]} {
        set fp [open $area_file "r"]
        while {[gets $fp line] >= 0} {
            if {[regexp {^\s*([a-zA-Z0-9_]+)\s+(\d+)\s+([\d\.]+)\s+([\d\.]+)\s+([\d\.]+)} $line -> inst count c_area n_area t_area]} {
                if {$inst eq $top_module} {
                    if {$tot_inst eq "N/A"}  { set tot_inst $count }
                    if {$tot_area eq "N/A"}  { set tot_area $t_area }
                    if {$cell_area eq "N/A"} { set cell_area $c_area }
                }
            }
        }
        close $fp
    }

    # Fallbacks for Area & Gate Counts
    if {$comb_inst eq "N/A" && $tot_inst ne "N/A"} { set comb_inst $tot_inst }
    if {$gate_cnt eq "N/A" && $tot_inst ne "N/A"}  { set gate_cnt $tot_inst }

    # 3. Parse Timing Report for Delay & WNS
    set timing_file "$rpt_dir/${top_module}_timing.rpt"
    if {[file exists $timing_file]} {
        set fp [open $timing_file "r"]
        while {[gets $fp line] >= 0} {
            if {[regexp -nocase {Slack[^\d\+\-]*([+\-]?[0-9\.]+)} $line match val]} {
                if {$wns eq "N/A"} { set wns $val }
            }
            if {[regexp -nocase {Data Path[^\d]*([0-9\.]+)} $line match val]} {
                set delay $val
            }
        }
        close $fp
    }

    # Fallback Delay calculation: Clock(10000) - Input_Delay(2000) - Output_Delay(2000) - Slack
    if {$delay eq "N/A" && $wns ne "N/A"} {
        set fallback [expr {10000.0 - 4000.0 - $wns}]
        set delay [format "%.1f" $fallback]
    }

    # Handle TNS: If design meets timing (positive slack), TNS is mathematically 0.0
    if {$tns eq "N/A"} {
        if {$wns ne "N/A" && $wns >= 0} {
            set tns "0.0"
        }
    }

    # 4. Parse Power Report & Convert to uW
    set power_file "$rpt_dir/${top_module}_power.rpt"
    if {[file exists $power_file]} {
        set fp [open $power_file "r"]
        while {[gets $fp line] >= 0} {
            set line_lower [string tolower $line]
            if {[string match "*$top_module*" $line_lower] || [string match "*total*" $line_lower]} {
                set nums [extract_floats $line]
                if {[llength $nums] >= 3} {
                    set leak_pwr [format_pwr [lindex $nums end-2]]
                    set dyn_pwr  [format_pwr [lindex $nums end-1]]
                    set tot_pwr  [format_pwr [lindex $nums end]]
                }
            }
        }
        close $fp
    }

    # Format row (150 chars wide)
    set row [format "│ %-11s │ %-10s │ %-10s │ %-10s │ %-10s │ %-10s │ %-9s │ %-8s │ %-8s │ %-9s │ %-9s │ %-9s │" \
        $stage $tot_area $cell_area $gate_cnt $tot_inst $comb_inst $delay $wns $tns $leak_pwr $dyn_pwr $tot_pwr]
    
    puts $row
    puts $txt_out $row
}

# Print footer
puts $hr_bot
puts $txt_out $hr_bot

close $txt_out
puts "\nReport successfully generated and saved to $output_txt\n"
