# ====================================================================
# Cadence Genus Synthesis Script for Combinational RCA
# Extracts reports at Generic, Mapped, and Optimized stages.
# ====================================================================

# Set Library Paths (Using 90nm slow corner as a baseline)
set_db init_lib_search_path /home/install/FOUNDRY/digital/90nm/dig/lib
set_db library slow.lib

set TOP_MODULE "rca_4bit"

# Create report directories for each stage
file mkdir reports/generic
file mkdir reports/mapped
file mkdir reports/optimized

# Load Design
read_hdl rca_4bit.v
elaborate $TOP_MODULE
read_sdc rca_4bit.sdc

# --------------------------------------------------------------------
# STAGE 1: GENERIC SYNTHESIS
# --------------------------------------------------------------------
set_db syn_generic_effort medium
syn_generic

report_timing > reports/generic/${TOP_MODULE}_timing.rpt
report_area   > reports/generic/${TOP_MODULE}_area.rpt
report_power  > reports/generic/${TOP_MODULE}_power.rpt
report_qor    > reports/generic/${TOP_MODULE}_qor.rpt

# --------------------------------------------------------------------
# STAGE 2: MAPPED SYNTHESIS
# --------------------------------------------------------------------
set_db syn_map_effort medium
syn_map

report_timing > reports/mapped/${TOP_MODULE}_timing.rpt
report_area   > reports/mapped/${TOP_MODULE}_area.rpt
report_power  > reports/mapped/${TOP_MODULE}_power.rpt
report_qor    > reports/mapped/${TOP_MODULE}_qor.rpt

# --------------------------------------------------------------------
# STAGE 3: OPTIMIZED SYNTHESIS
# --------------------------------------------------------------------
set_db syn_opt_effort medium
syn_opt

report_timing > reports/optimized/${TOP_MODULE}_timing.rpt
report_area   > reports/optimized/${TOP_MODULE}_area.rpt
report_power  > reports/optimized/${TOP_MODULE}_power.rpt
report_qor    > reports/optimized/${TOP_MODULE}_qor.rpt

puts "\n================================================="
puts "SYNTHESIS AND MULTI-STAGE REPORTING COMPLETE!"
puts "=================================================\n"
gui_show
