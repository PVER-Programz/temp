module fa_tb();
reg a_tb,b_tb,c_tb;
wire sum_tb,cout_tb;

fa uut(.a(a_tb), .b(b_tb), .cin(c_tb), .sum(sum_tb), .cout(cout_tb));

initial begin
$monitor("Time - %0d a = %ob b = %0b cin = %0b sum = %0b cout = %0b", $time, a_tb, b_tb, c_tb, sum_tb, cout_tb);
a_tb = 1'b0; b_tb = 1'b0; c_tb = 1'b0; #10;
a_tb = 1'b0; b_tb = 1'b0; c_tb = 1'b1; #10;
a_tb = 1'b0; b_tb = 1'b1; c_tb = 1'b0; #10;
a_tb = 1'b0; b_tb = 1'b1; c_tb = 1'b1; #10;
a_tb = 1'b1; b_tb = 1'b0; c_tb = 1'b0; #10;
a_tb = 1'b1; b_tb = 1'b0; c_tb = 1'b1; #10;
a_tb = 1'b1; b_tb = 1'b1; c_tb = 1'b0; #10;
a_tb = 1'b1; b_tb = 1'b1; c_tb = 1'b1; #10;
$finish;
end
endmodule

